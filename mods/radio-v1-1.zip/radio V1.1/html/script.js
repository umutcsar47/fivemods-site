﻿const app = document.getElementById("app")
const radioPanel = document.getElementById("radioPanel")
const dragHandle = document.getElementById("dragHandle")

const settingsBtn = document.getElementById("settingsBtn")
const closeBtn = document.getElementById("closeBtn")

const urlInput = document.getElementById("urlInput")
const titleRow = document.getElementById("titleRow")
const titleText = document.getElementById("titleText")
const editLinkBtn = document.getElementById("editLinkBtn")

const transportToggleBtn = document.getElementById("transportToggleBtn")
const transportIcon = document.getElementById("transportIcon")
const stopBtn = document.getElementById("stopBtn")

const volumeInput = document.getElementById("volumeInput")
const distanceInput = document.getElementById("distanceInput")
const volumeValue = document.getElementById("volumeValue")
const distanceValue = document.getElementById("distanceValue")
const statusBox = document.getElementById("statusBox")

const sizeOverlay = document.getElementById("sizeOverlay")
const sizeInput = document.getElementById("sizeInput")
const sizeValue = document.getElementById("sizeValue")
const sizeDoneBtn = document.getElementById("sizeDoneBtn")

const controls = document.querySelectorAll(".control")

const ICON_PLAY = '<svg viewBox="0 0 24 24" aria-hidden="true" class="icon-svg"><path d="M8 6v12l10-6z"></path></svg>'
const ICON_PAUSE = '<svg viewBox="0 0 24 24" aria-hidden="true" class="icon-svg"><path d="M7 6h4v12H7zM13 6h4v12h-4z"></path></svg>'

const VOLUME_SEND_DEBOUNCE_MS = 90
const MIN_PANEL_SCALE = 0.70
const MAX_PANEL_SCALE = 1.40

let volumeSendTimer = null
let resolveTimer = null

let transportState = "idle"
let activeUrl = ""
let activeTitle = ""
let pendingUrl = ""
let pendingTitle = ""

let canControl = true
let sizeModeOpen = false
let panelScale = 1.0
let panelXPercent = 60
let panelYPercent = 45
let dragState = null

function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value))
}

function post(action, payload = {}) {
    return fetch(`https://${GetParentResourceName()}/${action}`, {
        method: "POST",
        headers: { "Content-Type": "application/json; charset=UTF-8" },
        body: JSON.stringify(payload)
    }).then((res) => res.json().catch(() => ({})))
}

function setOpen(state) {
    app.classList.toggle("visible", state)
    if (!state) {
        closeAdjustMode(true)
    }
}

function setStatus(message, type = "idle") {
    statusBox.textContent = message
    statusBox.className = `status ${type === "idle" ? "" : type}`.trim()
}

function setTransportState(state) {
    transportState = state

    if (transportState === "playing") {
        transportIcon.innerHTML = ICON_PAUSE
        return
    }

    transportIcon.innerHTML = ICON_PLAY
}

function updateSliderTexts() {
    volumeValue.textContent = `${Math.round(Number(volumeInput.value))}%`
    distanceValue.textContent = `${Math.round(Number(distanceInput.value))}m`
    sizeValue.textContent = `${Math.round(Number(sizeInput.value))}%`
}

function showTitlePreview(title) {
    if (!title) {
        return
    }

    titleText.textContent = title
    titleRow.classList.remove("hidden")
    urlInput.classList.add("hidden")
}

function showLinkInput(value) {
    titleRow.classList.add("hidden")
    urlInput.classList.remove("hidden")
    urlInput.value = value || ""
}

function clearPending() {
    pendingUrl = ""
    pendingTitle = ""
}

function handleResponse(promise, successMessage) {
    return promise
        .then((response) => {
            if (response && response.ok) {
                setStatus(successMessage, "ok")
                return response
            }

            setStatus((response && response.error) || "Islem basarisiz.", "error")
            return null
        })
        .catch(() => {
            setStatus("NUI baglanti hatasi.", "error")
            return null
        })
}

function resolveTitleFromInput(url) {
    const safeUrl = (url || "").trim()
    if (!safeUrl || transportState !== "idle") {
        return
    }

    post("resolveTitle", { url: safeUrl }).then((response) => {
        if (!response || response.ok !== true) {
            pendingUrl = safeUrl
            pendingTitle = safeUrl
            showTitlePreview(pendingTitle)
            setStatus((response && response.error) || "Sarki adi alinamadi.", "warn")
            return
        }

        pendingUrl = (response.url || safeUrl).trim()
        pendingTitle = (response.title || safeUrl).trim()
        showTitlePreview(pendingTitle)
        setStatus("şarkı adı bulundu.", "ok")
    })
}

function scheduleTitleResolve() {
    if (resolveTimer) {
        clearTimeout(resolveTimer)
    }

    resolveTimer = setTimeout(() => {
        resolveTimer = null
        resolveTitleFromInput(urlInput.value)
    }, 450)
}

function getCandidateUrl() {
    const value = urlInput.value.trim()
    if (value) {
        pendingUrl = value
        return value
    }

    return pendingUrl || activeUrl
}

function getCandidateTitle(url) {
    return pendingTitle || activeTitle || url
}

function updateControlState() {
    const disabled = !canControl || sizeModeOpen
    controls.forEach((control) => {
        control.disabled = disabled
    })
}

function setPanelPositionPx(leftPx, topPx) {
    const rect = radioPanel.getBoundingClientRect()
    const maxLeft = Math.max(0, window.innerWidth - rect.width)
    const maxTop = Math.max(0, window.innerHeight - rect.height)

    const finalLeft = clamp(leftPx, 0, maxLeft)
    const finalTop = clamp(topPx, 0, maxTop)

    radioPanel.style.left = `${finalLeft}px`
    radioPanel.style.top = `${finalTop}px`

    panelXPercent = clamp((finalLeft / Math.max(window.innerWidth, 1)) * 100, 1, 99)
    panelYPercent = clamp((finalTop / Math.max(window.innerHeight, 1)) * 100, 1, 99)
}

function setPanelPositionPercent(xPercent, yPercent) {
    panelXPercent = clamp(Number(xPercent) || 60, 1, 99)
    panelYPercent = clamp(Number(yPercent) || 45, 1, 99)
    radioPanel.style.left = `${panelXPercent}vw`
    radioPanel.style.top = `${panelYPercent}vh`
}

function setPanelScale(scale) {
    panelScale = clamp(scale, MIN_PANEL_SCALE, MAX_PANEL_SCALE)
    radioPanel.style.setProperty("--panel-scale", panelScale.toFixed(2))
    sizeInput.value = String(Math.round(panelScale * 100))
    updateSliderTexts()
}

function openAdjustMode() {
    sizeModeOpen = true
    sizeOverlay.classList.remove("hidden")
    radioPanel.classList.add("position-edit")
    updateControlState()
    setStatus("Ayar Modu Aktif; boyutunu ve konumunu özelleştir.", "warn")
}

function closeAdjustMode(silent = false) {
    sizeModeOpen = false
    sizeOverlay.classList.add("hidden")
    radioPanel.classList.remove("position-edit")
    updateControlState()
    if (!silent) {
        setStatus("Ayar modu kapatıldı.", "ok")
    }
}

settingsBtn.addEventListener("click", () => {
    if (!canControl || sizeModeOpen) {
        return
    }

    openAdjustMode()
})

sizeInput.addEventListener("input", () => {
    const scale = clamp(Number(sizeInput.value) / 100, MIN_PANEL_SCALE, MAX_PANEL_SCALE)
    setPanelScale(scale)
})

sizeDoneBtn.addEventListener("click", async () => {
    const scale = clamp(Number(sizeInput.value) / 100, MIN_PANEL_SCALE, MAX_PANEL_SCALE)
    const response = await handleResponse(post("setUiLayout", { scale }), "Boyut kaydedildi.")
    if (response && typeof response.scale === "number") {
        setPanelScale(response.scale)
    }

    await post("setUiPosition", { x: panelXPercent, y: panelYPercent })
    closeAdjustMode()
})

closeBtn.addEventListener("click", async () => {
    if (sizeModeOpen) {
        return
    }
    await post("close")
    setOpen(false)
})

editLinkBtn.addEventListener("click", () => {
    if (transportState !== "idle") {
        setStatus("Link Değiştirmek için şarkıyı bitir.", "warn")
        return
    }

    showLinkInput(pendingUrl || activeUrl || "")
    setStatus("Yeni link girebilirsin.", "idle")
    urlInput.focus()
})

transportToggleBtn.addEventListener("click", async () => {
    if (sizeModeOpen) {
        return
    }

    const candidateUrl = getCandidateUrl()
    const selectedDistance = clamp(Number(distanceInput.value), 8, 80)

    if (transportState === "idle") {
        if (!candidateUrl) {
            setStatus("YouTube veya stream linki girmelisin.", "warn")
            return
        }

        const response = await handleResponse(
            post("play", {
                url: candidateUrl,
                volume: clamp(Number(volumeInput.value) / 100, 0.05, 1.0),
                distance: selectedDistance
            }),
            "Radyo acildi."
        )

        if (response) {
            activeUrl = candidateUrl
            activeTitle = getCandidateTitle(candidateUrl)
            showTitlePreview(activeTitle)
            setTransportState("playing")
        }
        return
    }

    if (transportState === "playing") {
        const response = await handleResponse(post("pause"), "Radyo durduruldu.")
        if (response) {
            setTransportState("paused")
        }
        return
    }

    const response = await handleResponse(post("resume"), "Radyo devam ediyor.")
    if (response) {
        setTransportState("playing")
    }
})

stopBtn.addEventListener("click", async () => {
    if (sizeModeOpen) {
        return
    }

    const response = await handleResponse(post("stop"), "Radyo bitirildi.")
    if (response) {
        activeUrl = ""
        activeTitle = ""
        clearPending()
        setTransportState("idle")
        showLinkInput("")
        urlInput.focus()
    }
})

volumeInput.addEventListener("input", () => {
    updateSliderTexts()

    if (volumeSendTimer) {
        clearTimeout(volumeSendTimer)
    }

    volumeSendTimer = setTimeout(() => {
        volumeSendTimer = null
        if (transportState === "idle") {
            return
        }
        post("setVolume", { volume: clamp(Number(volumeInput.value) / 100, 0.05, 1.0) })
    }, VOLUME_SEND_DEBOUNCE_MS)
})

volumeInput.addEventListener("change", () => {
    if (volumeSendTimer) {
        clearTimeout(volumeSendTimer)
        volumeSendTimer = null
    }

    if (transportState !== "idle") {
        handleResponse(post("setVolume", { volume: clamp(Number(volumeInput.value) / 100, 0.05, 1.0) }), "Ses guncellendi.")
    }
})

distanceInput.addEventListener("input", () => {
    updateSliderTexts()
})

distanceInput.addEventListener("change", () => {
    const distance = clamp(Number(distanceInput.value), 8, 80)
    handleResponse(post("setDistance", { distance }), "3D mesafe guncellendi.")
})

urlInput.addEventListener("input", () => {
    if (transportState !== "idle") {
        return
    }

    clearPending()
    const current = urlInput.value.trim()
    if (!current) {
        setStatus("Link bekleniyor...", "idle")
        return
    }

    scheduleTitleResolve()
})

urlInput.addEventListener("paste", () => {
    if (transportState !== "idle") {
        return
    }

    setTimeout(() => {
        const value = urlInput.value.trim()
        if (value) {
            resolveTitleFromInput(value)
        }
    }, 20)
})

urlInput.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" || transportState !== "idle") {
        return
    }

    const value = urlInput.value.trim()
    if (value) {
        resolveTitleFromInput(value)
    }
})

if (dragHandle) {
    dragHandle.addEventListener("mousedown", (event) => {
        if (!app.classList.contains("visible") || !sizeModeOpen) {
            return
        }

        if (event.button !== 0) {
            return
        }

        if (event.target.closest("button") || event.target.closest("input")) {
            return
        }

        const rect = radioPanel.getBoundingClientRect()
        dragState = {
            startX: event.clientX,
            startY: event.clientY,
            startLeft: rect.left,
            startTop: rect.top
        }

        document.body.style.userSelect = "none"
    })
}

window.addEventListener("mousemove", (event) => {
    if (!dragState) {
        return
    }

    const deltaX = event.clientX - dragState.startX
    const deltaY = event.clientY - dragState.startY
    const nextLeft = dragState.startLeft + deltaX
    const nextTop = dragState.startTop + deltaY

    setPanelPositionPx(nextLeft, nextTop)
})

window.addEventListener("mouseup", async () => {
    if (!dragState) {
        return
    }

    dragState = null
    document.body.style.userSelect = ""

    await post("setUiPosition", { x: panelXPercent, y: panelYPercent })
})

window.addEventListener("resize", () => {
    setPanelPositionPercent(panelXPercent, panelYPercent)
})

window.addEventListener("message", (event) => {
    const data = event.data || {}

    if (data.action === "open") {
        setOpen(true)
        return
    }

    if (data.action === "close") {
        setOpen(false)
        return
    }

    if (data.action === "error") {
        setStatus(data.message || "Radyo hatasi.", "error")
        return
    }

    if (data.action === "setState") {
        canControl = data.canControl !== false
        updateControlState()

        if (!canControl) {
            setTransportState("idle")
            setStatus(data.error || "Radyoyu kullanmak icin araca bin.", "warn")
            return
        }

        const station = data.station || {}
        if (station.playing) {
            activeUrl = station.rawUrl || station.url || ""
            activeTitle = station.title || activeUrl
            pendingTitle = activeTitle
            pendingUrl = activeUrl
            showTitlePreview(activeTitle)
            setTransportState(station.paused ? "paused" : "playing")
            if (typeof station.volume === "number") {
                volumeInput.value = String(Math.round(clamp(station.volume, 0.05, 1.0) * 100))
            }
            if (typeof station.distance === "number") {
                distanceInput.value = String(Math.round(clamp(station.distance, 8, 80)))
            }
        } else {
            activeUrl = ""
            activeTitle = ""
            clearPending()
            showLinkInput("")
            setTransportState("idle")
        }

        if (data.ui && data.ui.position) {
            setPanelPositionPercent(data.ui.position.x || 60, data.ui.position.y || 45)
        }
        if (data.ui && typeof data.ui.scale === "number") {
            setPanelScale(data.ui.scale)
        }

        updateSliderTexts()
    }
})

document.addEventListener("keyup", async (event) => {
    if (event.key !== "Escape" || !app.classList.contains("visible")) {
        return
    }

    if (sizeModeOpen) {
        return
    }

    await post("close")
    setOpen(false)
})

showLinkInput("")
setTransportState("idle")
updateSliderTexts()
setStatus("Hazir.", "idle")
updateControlState()
