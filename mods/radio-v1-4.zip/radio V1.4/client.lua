local RADIO_COMMAND = "carradio"
local SOUND_PREFIX = "car_radio_"

local DEFAULT_VOLUME = 0.50
local DEFAULT_DISTANCE = 35.0
local MIN_VOLUME = 0.05
local MAX_VOLUME = 1.00
local MIN_DISTANCE = 8.0
local MAX_DISTANCE = 80.0

local VOLUME_CURVE_EXPONENT = 0.35
local MAX_EFFECTIVE_VOLUME = 2.40
local MIN_EFFECTIVE_VOLUME = 0.05
local DEFAULT_UI_SCALE = 1.00
local MIN_UI_SCALE = 0.70
local MAX_UI_SCALE = 1.40
local DEFAULT_UI_WIDTH = 0.96
local MIN_UI_WIDTH = 0.85
local MAX_UI_WIDTH = 1.30
local DEFAULT_UI_HEIGHT = 1.00
local MIN_UI_HEIGHT = 0.70
local MAX_UI_HEIGHT = 1.80
local DEFAULT_UI_POS_X = 76.0
local DEFAULT_UI_POS_Y = 48.0

local KVP_UI_SCALE = "car_radio_ui_scale"
local KVP_UI_WIDTH = "car_radio_ui_width"
local KVP_UI_HEIGHT = "car_radio_ui_height"
local KVP_UI_POS_X = "car_radio_ui_pos_x"
local KVP_UI_POS_Y = "car_radio_ui_pos_y"

local TITLE_REQUEST_TIMEOUT_MS = 7000
local INSIDE_DISTANCE_OVERRIDE = 1000.0

local uiOpen = false
local stations = {}
local soundParamsCache = {}
local pendingTitleRequests = {}
local titleRequestSeq = 0

local uiScale = DEFAULT_UI_SCALE
local uiWidth = DEFAULT_UI_WIDTH
local uiHeight = DEFAULT_UI_HEIGHT
local uiPosX = DEFAULT_UI_POS_X
local uiPosY = DEFAULT_UI_POS_Y

local function clamp(value, minValue, maxValue)
    if value < minValue then
        return minValue
    end

    if value > maxValue then
        return maxValue
    end

    return value
end

local function trim(value)
    return value:gsub("^%s+", ""):gsub("%s+$", "")
end

local function notify(message)
    BeginTextCommandThefeedPost("STRING")
    AddTextComponentSubstringPlayerName(message)
    EndTextCommandThefeedPostTicker(false, false)
end

local function loadNumberKvp(key, defaultValue, minValue, maxValue)
    local raw = GetResourceKvpString(key)
    local parsed = tonumber(raw)
    if not parsed then
        return defaultValue
    end

    return clamp(parsed, minValue, maxValue)
end

local function loadUiSettings()
    uiScale = loadNumberKvp(KVP_UI_SCALE, DEFAULT_UI_SCALE, MIN_UI_SCALE, MAX_UI_SCALE)
    uiWidth = loadNumberKvp(KVP_UI_WIDTH, DEFAULT_UI_WIDTH, MIN_UI_WIDTH, MAX_UI_WIDTH)
    uiHeight = loadNumberKvp(KVP_UI_HEIGHT, DEFAULT_UI_HEIGHT, MIN_UI_HEIGHT, MAX_UI_HEIGHT)
    uiPosX = loadNumberKvp(KVP_UI_POS_X, DEFAULT_UI_POS_X, 1.0, 99.0)
    uiPosY = loadNumberKvp(KVP_UI_POS_Y, DEFAULT_UI_POS_Y, 1.0, 99.0)
end

local function saveUiScale(value)
    uiScale = clamp(value, MIN_UI_SCALE, MAX_UI_SCALE)
    SetResourceKvp(KVP_UI_SCALE, ("%.3f"):format(uiScale))
end

local function saveUiSize(widthScale, heightScale)
    uiWidth = clamp(widthScale, MIN_UI_WIDTH, MAX_UI_WIDTH)
    uiHeight = clamp(heightScale, MIN_UI_HEIGHT, MAX_UI_HEIGHT)

    SetResourceKvp(KVP_UI_WIDTH, ("%.3f"):format(uiWidth))
    SetResourceKvp(KVP_UI_HEIGHT, ("%.3f"):format(uiHeight))
end

local function saveUiPosition(x, y)
    uiPosX = clamp(x, 1.0, 99.0)
    uiPosY = clamp(y, 1.0, 99.0)

    SetResourceKvp(KVP_UI_POS_X, ("%.4f"):format(uiPosX))
    SetResourceKvp(KVP_UI_POS_Y, ("%.4f"):format(uiPosY))
end

local function distanceFromVolume(volume)
    local ratio = (volume - MIN_VOLUME) / (MAX_VOLUME - MIN_VOLUME)
    ratio = clamp(ratio, 0.0, 1.0)
    return clamp(MIN_DISTANCE + ((MAX_DISTANCE - MIN_DISTANCE) * ratio), MIN_DISTANCE, MAX_DISTANCE)
end

local function isValidSupportedVehicle(vehicle)
    if vehicle == 0 or not DoesEntityExist(vehicle) then
        return false
    end

    local model = GetEntityModel(vehicle)
    return IsThisModelACar(model) or IsThisModelABike(model)
end

local function getPlayerVehicle()
    local ped = PlayerPedId()

    if not IsPedInAnyVehicle(ped, false) then
        return nil, "bir aracın içinde olmalısın."
    end

    local vehicle = GetVehiclePedIsIn(ped, false)
    if not isValidSupportedVehicle(vehicle) then
        return nil, "."
    end

    local netId = NetworkGetNetworkIdFromEntity(vehicle)
    if netId == 0 then
        return nil, "Arac bilgisi alınamadı."
    end

    return vehicle, nil, netId
end

local function getSoundId(netId)
    return ("%s%d"):format(SOUND_PREFIX, netId)
end

local function shouldUse2DForLocalPlayer(vehicle)
    local ped = PlayerPedId()
    if ped == 0 or not IsPedInAnyVehicle(ped, false) then
        return false
    end

    local currentVehicle = GetVehiclePedIsIn(ped, false)
    if currentVehicle == 0 then
        return false
    end

    return currentVehicle == vehicle
end

local function getPlaybackPosition(vehicle, insideVehicle)
    if insideVehicle then
        local ped = PlayerPedId()
        if ped ~= 0 then
            return GetEntityCoords(ped)
        end
    end

    return GetEntityCoords(vehicle)
end

local function getEffectiveVolume(baseVolume)
    return clamp(baseVolume, MIN_VOLUME, MAX_VOLUME)
end

local function closeUi()
    if not uiOpen then
        return
    end

    uiOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "close" })
end

local function copyStation(station)
    return {
        url = station.url,
        rawUrl = station.rawUrl,
        title = station.title,
        volume = station.volume,
        distance = station.distance,
        paused = station.paused
    }
end

local function pushUiState()
    if not uiOpen then
        return
    end

    local vehicle, errorText, netId = getPlayerVehicle()
    if not vehicle then
        SendNUIMessage({
            action = "setState",
            canControl = false,
            error = errorText,
            ui = {
                scale = uiScale,
                width = uiWidth,
                height = uiHeight,
                position = { x = uiPosX, y = uiPosY }
            }
        })
        return
    end

    local station = stations[netId]
    SendNUIMessage({
        action = "setState",
        canControl = true,
        station = station and {
            url = station.rawUrl or station.url,
            rawUrl = station.rawUrl or station.url,
            title = station.title or station.rawUrl or station.url,
            volume = station.volume,
            distance = station.distance,
            paused = station.paused,
            playing = true
        } or {
            url = "",
            rawUrl = "",
            title = "",
            volume = DEFAULT_VOLUME,
            distance = DEFAULT_DISTANCE,
            paused = false,
            playing = false
        },
        ui = {
            scale = uiScale,
            width = uiWidth,
            height = uiHeight,
            position = { x = uiPosX, y = uiPosY }
        }
    })
end

local function openUi()
    local vehicle, errorText = getPlayerVehicle()
    if not vehicle then
        notify(errorText)
        return
    end

    uiOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = "open" })
    pushUiState()
end

local function toggleUi()
    if uiOpen then
        closeUi()
    else
        openUi()
    end
end

local function stopStation(netId)
    local soundId = getSoundId(netId)
    if exports.xsound:soundExists(soundId) then
        exports.xsound:Destroy(soundId)
    end

    stations[netId] = nil
    soundParamsCache[netId] = nil
end

local function getEffectiveDistanceForStation(stationDistance)
    return clamp(stationDistance, MIN_DISTANCE, MAX_DISTANCE)
end

local function applySoundParams(netId, soundId, volume, distance, insideVehicle)
    local cache = soundParamsCache[netId]
    if not cache then
        cache = {}
        soundParamsCache[netId] = cache
    end

    local distanceToApply = insideVehicle and INSIDE_DISTANCE_OVERRIDE or distance
    if not cache.distance or math.abs(cache.distance - distanceToApply) > 0.5 then
        exports.xsound:Distance(soundId, distanceToApply)
        cache.distance = distanceToApply
    end

    if not cache.volume or math.abs(cache.volume - volume) > 0.01 then
        exports.xsound:setVolume(soundId, volume)
        cache.volume = volume
    end
end

local function playOrRefreshStation(netId, station)
    local vehicle = NetworkGetEntityFromNetworkId(netId)
    if vehicle == 0 or not DoesEntityExist(vehicle) then
        return
    end

    local soundId = getSoundId(netId)
    local exists = exports.xsound:soundExists(soundId)

    local effectiveVolume = getEffectiveVolume(station.volume)
    local effectiveDistance = getEffectiveDistanceForStation(station.distance)
    local insideVehicle = shouldUse2DForLocalPlayer(vehicle)
    local playbackPos = getPlaybackPosition(vehicle, insideVehicle)

    if exists then
        local info = exports.xsound:getInfo(soundId)
        if not info or info.url ~= station.url then
            exports.xsound:Destroy(soundId)
            exists = false
            soundParamsCache[netId] = nil
        end
    end

    if not exists then
        exports.xsound:PlayUrlPos(soundId, station.url, effectiveVolume, playbackPos, true)
    end

    if not exports.xsound:soundExists(soundId) then
        return
    end

    exports.xsound:Position(soundId, playbackPos)
    applySoundParams(netId, soundId, effectiveVolume, effectiveDistance, insideVehicle)

    if station.paused then
        exports.xsound:Pause(soundId)
    else
        exports.xsound:Resume(soundId)
    end
end

loadUiSettings()

RegisterCommand(RADIO_COMMAND, function()
    toggleUi()
end, false)

RegisterCommand("aracradyo", function()
    toggleUi()
end, false)

RegisterKeyMapping(RADIO_COMMAND, "araclar 3D Radyo", "keyboard", "F7")

RegisterNUICallback("close", function(_, cb)
    closeUi()
    cb({ ok = true })
end)

RegisterNUICallback("play", function(data, cb)
    local vehicle, errorText, netId = getPlayerVehicle()
    if not vehicle then
        cb({ ok = false, error = errorText })
        return
    end

    local url = type(data.url) == "string" and trim(data.url) or ""
    if url == "" then
        cb({ ok = false, error = "Lütfen bir Youtube Linki girin." })
        return
    end

    local volume = clamp(tonumber(data.volume) or DEFAULT_VOLUME, MIN_VOLUME, MAX_VOLUME)
    local distance = clamp(tonumber(data.distance) or distanceFromVolume(volume), MIN_DISTANCE, MAX_DISTANCE)

    TriggerServerEvent("car_radio:server:play", netId, url, volume, distance)
    cb({ ok = true, volume = volume, distance = distance })
end)

RegisterNUICallback("pause", function(_, cb)
    local vehicle, errorText, netId = getPlayerVehicle()
    if not vehicle then
        cb({ ok = false, error = errorText })
        return
    end

    TriggerServerEvent("car_radio:server:pause", netId)
    cb({ ok = true })
end)

RegisterNUICallback("resume", function(_, cb)
    local vehicle, errorText, netId = getPlayerVehicle()
    if not vehicle then
        cb({ ok = false, error = errorText })
        return
    end

    TriggerServerEvent("car_radio:server:resume", netId)
    cb({ ok = true })
end)

RegisterNUICallback("stop", function(_, cb)
    local vehicle, errorText, netId = getPlayerVehicle()
    if not vehicle then
        cb({ ok = false, error = errorText })
        return
    end

    TriggerServerEvent("car_radio:server:stop", netId)
    cb({ ok = true })
end)

RegisterNUICallback("setVolume", function(data, cb)
    local vehicle, errorText, netId = getPlayerVehicle()
    if not vehicle then
        cb({ ok = false, error = errorText })
        return
    end

    local volume = clamp(tonumber(data.volume) or DEFAULT_VOLUME, MIN_VOLUME, MAX_VOLUME)
    local distance = nil

    if data.distance ~= nil then
        distance = clamp(tonumber(data.distance) or DEFAULT_DISTANCE, MIN_DISTANCE, MAX_DISTANCE)
    end

    TriggerServerEvent("car_radio:server:setVolume", netId, volume, distance)
    cb({ ok = true, volume = volume, distance = distance })
end)

RegisterNUICallback("setDistance", function(data, cb)
    local vehicle, errorText, netId = getPlayerVehicle()
    if not vehicle then
        cb({ ok = false, error = errorText })
        return
    end

    local distance = clamp(tonumber(data.distance) or DEFAULT_DISTANCE, MIN_DISTANCE, MAX_DISTANCE)
    TriggerServerEvent("car_radio:server:setDistance", netId, distance)
    cb({ ok = true, distance = distance })
end)

RegisterNUICallback("resolveTitle", function(data, cb)
    local url = type(data.url) == "string" and trim(data.url) or ""
    if url == "" then
        cb({ ok = false, error = "Link boş." })
        return
    end

    titleRequestSeq = titleRequestSeq + 1
    local requestId = titleRequestSeq
    pendingTitleRequests[requestId] = cb

    TriggerServerEvent("car_radio:server:resolveTitle", requestId, url)

    SetTimeout(TITLE_REQUEST_TIMEOUT_MS, function()
        local pending = pendingTitleRequests[requestId]
        if not pending then
            return
        end

        pendingTitleRequests[requestId] = nil
        pending({ ok = false, error = "Sarkı adı alınamadı." })
    end)
end)

RegisterNUICallback("setUiScale", function(data, cb)
    local newScale = clamp(tonumber(data.scale) or uiScale, MIN_UI_SCALE, MAX_UI_SCALE)
    saveUiScale(newScale)
    cb({ ok = true, scale = uiScale })
end)

RegisterNUICallback("setUiSize", function(data, cb)
    local widthScale = clamp(tonumber(data.width) or uiWidth, MIN_UI_WIDTH, MAX_UI_WIDTH)
    local heightScale = clamp(tonumber(data.height) or uiHeight, MIN_UI_HEIGHT, MAX_UI_HEIGHT)

    saveUiSize(widthScale, heightScale)
    cb({ ok = true, width = uiWidth, height = uiHeight })
end)

RegisterNUICallback("setUiLayout", function(data, cb)
    local newScale = clamp(tonumber(data.scale) or uiScale, MIN_UI_SCALE, MAX_UI_SCALE)
    local widthScale = clamp(tonumber(data.width) or uiWidth, MIN_UI_WIDTH, MAX_UI_WIDTH)
    local heightScale = clamp(tonumber(data.height) or uiHeight, MIN_UI_HEIGHT, MAX_UI_HEIGHT)

    saveUiScale(newScale)
    saveUiSize(widthScale, heightScale)

    cb({
        ok = true,
        scale = uiScale,
        width = uiWidth,
        height = uiHeight
    })
end)

RegisterNUICallback("setUiPosition", function(data, cb)
    local x = clamp(tonumber(data.x) or uiPosX, 1.0, 99.0)
    local y = clamp(tonumber(data.y) or uiPosY, 1.0, 99.0)

    saveUiPosition(x, y)
    cb({ ok = true, x = uiPosX, y = uiPosY })
end)

RegisterNetEvent("car_radio:client:notify", function(message)
    if type(message) ~= "string" or message == "" then
        return
    end

    notify(message)

    if uiOpen then
        SendNUIMessage({
            action = "error",
            message = message
        })
    end
end)

RegisterNetEvent("car_radio:client:resolveTitleResult", function(requestId, ok, title, url, errorText)
    requestId = tonumber(requestId)
    if not requestId then
        return
    end

    local cb = pendingTitleRequests[requestId]
    if not cb then
        return
    end

    pendingTitleRequests[requestId] = nil
    cb({
        ok = ok == true,
        title = title,
        url = url,
        error = errorText
    })
end)

RegisterNetEvent("car_radio:client:updateStation", function(netId, station)
    netId = tonumber(netId)
    if not netId or type(station) ~= "table" or type(station.url) ~= "string" then
        return
    end

    station.volume = clamp(tonumber(station.volume) or DEFAULT_VOLUME, MIN_VOLUME, MAX_VOLUME)
    station.distance = clamp(tonumber(station.distance) or distanceFromVolume(station.volume), MIN_DISTANCE, MAX_DISTANCE)
    station.paused = station.paused == true
    station.rawUrl = type(station.rawUrl) == "string" and station.rawUrl or station.url
    station.title = type(station.title) == "string" and station.title or station.rawUrl

    stations[netId] = copyStation(station)
    playOrRefreshStation(netId, stations[netId])
    pushUiState()
end)

RegisterNetEvent("car_radio:client:removeStation", function(netId)
    netId = tonumber(netId)
    if not netId then
        return
    end

    stopStation(netId)
    pushUiState()
end)

RegisterNetEvent("car_radio:client:syncStations", function(serverStations)
    local keep = {}

    for key, station in pairs(serverStations or {}) do
        local netId = tonumber(key)
        if netId and type(station) == "table" and type(station.url) == "string" then
            station.volume = clamp(tonumber(station.volume) or DEFAULT_VOLUME, MIN_VOLUME, MAX_VOLUME)
            station.distance = clamp(tonumber(station.distance) or distanceFromVolume(station.volume), MIN_DISTANCE, MAX_DISTANCE)
            station.paused = station.paused == true
            station.rawUrl = type(station.rawUrl) == "string" and station.rawUrl or station.url
            station.title = type(station.title) == "string" and station.title or station.rawUrl

            stations[netId] = copyStation(station)
            keep[netId] = true
            playOrRefreshStation(netId, stations[netId])
        end
    end

    for netId in pairs(stations) do
        if not keep[netId] then
            stopStation(netId)
        end
    end

    pushUiState()
end)

CreateThread(function()
    Wait(2500)
    TriggerServerEvent("car_radio:server:requestSync")
end)

AddEventHandler("onClientResourceStart", function(resourceName)
    if resourceName ~= GetCurrentResourceName() then
        return
    end

    Wait(1000)
    TriggerServerEvent("car_radio:server:requestSync")
end)

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName ~= GetCurrentResourceName() then
        return
    end

    SetNuiFocus(false, false)

    for netId in pairs(stations) do
        stopStation(netId)
    end

    for requestId, cb in pairs(pendingTitleRequests) do
        pendingTitleRequests[requestId] = nil
        cb({ ok = false, error = "UI kapatıldı." })
    end
end)

CreateThread(function()
    while true do
        local sleep = 900

        for netId, station in pairs(stations) do
            sleep = 140

            local vehicle = NetworkGetEntityFromNetworkId(netId)
            local soundId = getSoundId(netId)

            if vehicle ~= 0 and DoesEntityExist(vehicle) then
                if exports.xsound:soundExists(soundId) then
                    local effectiveVolume = getEffectiveVolume(station.volume)
                    local effectiveDistance = getEffectiveDistanceForStation(station.distance)
                    local insideVehicle = shouldUse2DForLocalPlayer(vehicle)
                    local playbackPos = getPlaybackPosition(vehicle, insideVehicle)

                    exports.xsound:Position(soundId, playbackPos)
                    applySoundParams(netId, soundId, effectiveVolume, effectiveDistance, insideVehicle)

                    if station.paused and not exports.xsound:isPaused(soundId) then
                        exports.xsound:Pause(soundId)
                    elseif not station.paused and exports.xsound:isPaused(soundId) then
                        exports.xsound:Resume(soundId)
                    end
                else
                    playOrRefreshStation(netId, station)
                end
            else
                stopStation(netId)
            end
        end

        Wait(sleep)
    end
end)

CreateThread(function()
    while true do
        if uiOpen then
            local vehicle = getPlayerVehicle()
            if not vehicle then
                closeUi()
            end
            Wait(250)
        else
            Wait(1000)
        end
    end
end)

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        if ped ~= 0 then
            if IsPedInAnyVehicle(ped, false) then
                local vehicle = GetVehiclePedIsIn(ped, false)
                if vehicle ~= 0 then
                    SetVehRadioStation(vehicle, "OFF")
                    SetVehicleRadioEnabled(vehicle, false)
                end
            end

            SetUserRadioControlEnabled(false)
        end

        Wait(500)
    end
end)
















