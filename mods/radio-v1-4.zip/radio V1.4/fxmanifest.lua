fx_version 'cerulean'
game 'gta5'
lua54 'yes'

ui_page 'html/index.html'

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

dependency 'xsound'
