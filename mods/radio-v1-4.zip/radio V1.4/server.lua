local DEFAULT_VOLUME = 0.50
local DEFAULT_DISTANCE = 35.0
local MIN_VOLUME = 0.05
local MAX_VOLUME = 1.00
local MIN_DISTANCE = 8.0
local MAX_DISTANCE = 80.0

local YTDLP_DEFAULT_BIN = "yt-dlp"
local YTDLP_PATH_CONVAR = "car_radio_ytdlp_path"
local YT_CACHE_TTL_SECONDS = 1200
local TITLE_CACHE_TTL_SECONDS = 7200

local stations = {}
local youtubeCache = {}
local ytdlpChecked = false
local ytdlpAvailable = false
local ytdlpPath = nil

local function clamp(value, minValue, maxValue)
    if value < minValue then
        return minValue
    end

    if value > maxValue then
        return maxValue
    end

    return value
end

local function trim(value)
    return value:gsub("^%s+", ""):gsub("%s+$", "")
end

local function sanitizeUrl(rawUrl)
    if type(rawUrl) ~= "string" then
        return nil
    end

    local url = trim(rawUrl)
    if url == "" then
        return nil
    end

    if not url:match("^https?://") then
        url = "https://" .. url
    end

    return url
end

local function sanitizeTitle(raw)
    if type(raw) ~= "string" then
        return nil
    end

    local title = raw:gsub("[\r\n]+", " ")
    title = title:gsub("%s+", " ")
    title = trim(title)

    if title == "" then
        return nil
    end

    return title
end

local function decodePercent(value)
    return (value:gsub("%%(%x%x)", function(hex)
        local number = tonumber(hex, 16)
        if not number then
            return " "
        end

        return string.char(number)
    end))
end

local function fallbackTitleFromUrl(url)
    local host = url:match("^https?://([^/%?#]+)") or "Stream"
    host = host:gsub("^www%.", "")

    local path = url:match("^https?://[^/]+/(.+)$") or ""
    local slug = path:match("([^/?#]+)[/?#]?$")

    if slug and slug ~= "" then
        slug = decodePercent(slug)
        slug = slug:gsub("[-_]+", " ")
        slug = slug:gsub("%s+", " ")
        slug = trim(slug)

        if #slug >= 3 then
            return slug
        end
    end

    return host
end

local function fileExists(path)
    local handle = io.open(path, "rb")
    if handle then
        handle:close()
        return true
    end

    return false
end

local function toWindowsPath(path)
    return path:gsub("/", "\\")
end

local function quoteBinary(bin)
    if bin:find("[/\\]") then
        return '"' .. toWindowsPath(bin) .. '"'
    end

    return '"' .. bin .. '"'
end

local function quoteArg(arg)
    arg = tostring(arg or "")
    arg = arg:gsub('"', "")
    return '"' .. arg .. '"'
end

local function canControlVehicle(source, netId)
    local ped = GetPlayerPed(source)
    if ped == 0 then
        return false
    end

    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 then
        return false
    end

    return NetworkGetNetworkIdFromEntity(vehicle) == netId
end

local function getStationKey(netId)
    return tostring(netId)
end

local function notifySource(source, message)
    TriggerClientEvent("car_radio:client:notify", source, message)
end

local function isYouTubeUrl(url)
    local lower = url:lower()
    return lower:find("youtube.com", 1, true) ~= nil or lower:find("youtu.be", 1, true) ~= nil
end

local function extractYouTubeId(url)
    local patterns = {
        "[?&]v=([%w_-]+)",
        "youtu%.be/([%w_-]+)",
        "youtube%.com/shorts/([%w_-]+)",
        "youtube%.com/live/([%w_-]+)",
        "youtube%.com/embed/([%w_-]+)",
        "youtube%.com/v/([%w_-]+)"
    }

    for _, pattern in ipairs(patterns) do
        local id = url:match(pattern)
        if id then
            id = id:sub(1, 11)
            if id:match("^[%w_-]+$") and #id == 11 then
                return id
            end
        end
    end

    return nil
end

local function collectYtDlpCandidates()
    local candidates = {}

    local function addCandidate(path)
        if type(path) ~= "string" then
            return
        end

        path = trim(path)
        if path == "" then
            return
        end

        for _, item in ipairs(candidates) do
            if item == path then
                return
            end
        end

        table.insert(candidates, path)
    end

    addCandidate(GetConvar(YTDLP_PATH_CONVAR, ""))
    addCandidate(YTDLP_DEFAULT_BIN)
    addCandidate("yt-dlp.exe")

    local resourcePath = (GetResourcePath(GetCurrentResourceName()) or ""):gsub("\\", "/")
    if resourcePath ~= "" then
        addCandidate(resourcePath .. "/yt-dlp.exe")
        addCandidate(resourcePath .. "/../yt-dlp.exe")
        addCandidate(resourcePath .. "/../../yt-dlp.exe")

        local serverRoot = resourcePath:gsub("/resources/[^/]+$", "")
        if serverRoot ~= "" then
            addCandidate(serverRoot .. "/yt-dlp.exe")

            local discoverCmd = ('cmd /C dir /b "%s\\yt-dlp*.exe" 2>nul'):format(toWindowsPath(serverRoot))
            local discoverHandle = io.popen(discoverCmd)
            if discoverHandle then
                for line in discoverHandle:lines() do
                    local name = trim(line)
                    if name ~= "" then
                        addCandidate(serverRoot .. "/" .. name)
                    end
                end

                discoverHandle:close()
            end
        end
    end

    return candidates
end

local function checkYtDlpAvailability()
    if ytdlpChecked then
        return ytdlpAvailable
    end

    ytdlpChecked = true

    local candidates = collectYtDlpCandidates()
    for _, candidate in ipairs(candidates) do
        local isPath = candidate:find("[/\\]") ~= nil

        if not isPath or fileExists(candidate) then
            local testCmd = quoteBinary(candidate) .. " --version 2>&1"
            local handle = io.popen(testCmd)

            if handle then
                local output = trim(handle:read("*a") or "")
                local ok, _, code = handle:close()
                local lower = output:lower()

                local valid = (ok == true or code == 0)
                    and output ~= ""
                    and lower:find("not recognized", 1, true) == nil
                    and lower:find("not found", 1, true) == nil

                if valid then
                    ytdlpAvailable = true
                    ytdlpPath = candidate
                    print(("[car_radio] yt-dlp bulundu: %s"):format(candidate))
                    return true
                end
            end
        end
    end

    print("[car_radio] yt-dlp bulunamadı. Gerekirse server.cfg içine setr car_radio_ytdlp_path \"D:/.../yt-dlp.exe\" ekle.")
    return false
end

local function setYoutubeCache(videoId, stream, title)
    local existing = youtubeCache[videoId] or {}

    youtubeCache[videoId] = {
        stream = stream or existing.stream,
        title = title or existing.title,
        time = os.time()
    }
end

local function urlEncode(value)
    value = tostring(value or "")
    return (value:gsub("([^%w%-_%.~])", function(c)
        return string.format("%%%02X", string.byte(c))
    end))
end

local function getYouTubeTitleFromOEmbed(youtubeUrl, videoId)
    local requestUrl = ("https://www.youtube.com/oembed?format=json&url=%s"):format(urlEncode(youtubeUrl))

    local p = promise.new()
    PerformHttpRequest(requestUrl, function(statusCode, body)
        if statusCode ~= 200 or type(body) ~= "string" or body == "" then
            p:resolve(nil)
            return
        end

        local ok, parsed = pcall(function()
            if type(json) == "table" and type(json.decode) == "function" then
                return json.decode(body)
            end

            return nil
        end)

        if not ok or type(parsed) ~= "table" then
            p:resolve(nil)
            return
        end

        local title = sanitizeTitle(parsed.title)
        p:resolve(title)
    end, "GET", "", { ["Accept"] = "application/json" })

    local title = Citizen.Await(p)
    if title and videoId then
        setYoutubeCache(videoId, nil, title)
    end

    return title
end

local function getYouTubeTitle(youtubeUrl, videoId)
    local cached = videoId and youtubeCache[videoId] or nil
    if cached and cached.title and (os.time() - cached.time) < TITLE_CACHE_TTL_SECONDS then
        return cached.title
    end

    if checkYtDlpAvailability() then
        local command = ('%s --no-playlist --no-warnings --skip-download --print "%%(title)s" %s 2>&1')
            :format(quoteBinary(ytdlpPath or YTDLP_DEFAULT_BIN), quoteArg(youtubeUrl))

        local handle = io.popen(command)
        if handle then
            local output = handle:read("*a") or ""
            handle:close()

            for line in output:gmatch("[^\r\n]+") do
                local title = sanitizeTitle(line)
                if title and not title:find("WARNING", 1, true) and not title:find("ERROR", 1, true) then
                    if videoId then
                        setYoutubeCache(videoId, nil, title)
                    end
                    return title
                end
            end
        end
    end

    return getYouTubeTitleFromOEmbed(youtubeUrl, videoId)
end

local function getYouTubeStreamUrl(youtubeUrl)
    local videoId = extractYouTubeId(youtubeUrl)
    if not videoId then
        return nil, "YouTube link formatı desteklenmiyor.", nil
    end

    local cached = youtubeCache[videoId]
    if cached and cached.stream and (os.time() - cached.time) < YT_CACHE_TTL_SECONDS then
        return cached.stream, nil, videoId
    end

    if not checkYtDlpAvailability() then
        return nil, "Serverda yt-dlp bulunamadı.", videoId
    end

    local canonicalUrl = "https://www.youtube.com/watch?v=" .. videoId
    local command = ('%s --no-playlist --no-warnings -f bestaudio -g %s 2>&1')
        :format(quoteBinary(ytdlpPath or YTDLP_DEFAULT_BIN), quoteArg(canonicalUrl))

    local handle = io.popen(command)
    if not handle then
        return nil, "yt-dlp çalıstırılamadı.", videoId
    end

    local output = handle:read("*a") or ""
    handle:close()

    for line in output:gmatch("[^\r\n]+") do
        local stream = trim(line)
        if stream:match("^https?://") then
            setYoutubeCache(videoId, stream, nil)
            return stream, nil, videoId
        end
    end

    return nil, "YouTube veya stream URL alınamadı.", videoId
end

local function resolveTrackTitle(url)
    if not isYouTubeUrl(url) then
        return fallbackTitleFromUrl(url)
    end

    local videoId = extractYouTubeId(url)
    local canonical = videoId and ("https://www.youtube.com/watch?v=" .. videoId) or url

    local title = getYouTubeTitle(canonical, videoId)
    if title then
        return title
    end

    if videoId then
        return "YouTube " .. videoId
    end

    return "YouTube"
end

local function resolvePlaybackUrlAndTitle(safeUrl)
    if not isYouTubeUrl(safeUrl) then
        return safeUrl, resolveTrackTitle(safeUrl), safeUrl, nil
    end

    local videoId = extractYouTubeId(safeUrl)
    local canonical = videoId and ("https://www.youtube.com/watch?v=" .. videoId) or safeUrl

    local streamUrl, streamErr = getYouTubeStreamUrl(canonical)
    local title = resolveTrackTitle(canonical)

    if streamUrl then
        return streamUrl, title, canonical, nil
    end

    return canonical, title, canonical, streamErr
end

local function broadcastStation(netId)
    local station = stations[getStationKey(netId)]
    if not station then
        return
    end

    TriggerClientEvent("car_radio:client:updateStation", -1, netId, station)
end

local function removeStation(netId)
    stations[getStationKey(netId)] = nil
    TriggerClientEvent("car_radio:client:removeStation", -1, netId)
end

RegisterNetEvent("car_radio:server:requestSync", function()
    TriggerClientEvent("car_radio:client:syncStations", source, stations)
end)

RegisterNetEvent("car_radio:server:resolveTitle", function(requestId, rawUrl)
    local src = source
    requestId = tonumber(requestId)

    if not requestId then
        return
    end

    local safeUrl = sanitizeUrl(rawUrl)
    if not safeUrl then
        TriggerClientEvent("car_radio:client:resolveTitleResult", src, requestId, false, nil, nil, "Gecersiz link.")
        return
    end

    local normalizedUrl = safeUrl
    local videoId = extractYouTubeId(safeUrl)
    if videoId then
        normalizedUrl = "https://www.youtube.com/watch?v=" .. videoId
    end

    local title = resolveTrackTitle(normalizedUrl)
    TriggerClientEvent("car_radio:client:resolveTitleResult", src, requestId, true, title, normalizedUrl, nil)
end)

RegisterNetEvent("car_radio:server:play", function(netId, url, volume, distance)
    local src = source
    netId = tonumber(netId)

    if not netId or not canControlVehicle(src, netId) then
        return
    end

    local safeUrl = sanitizeUrl(url)
    if not safeUrl then
        notifySource(src, "Gecersiz link.")
        return
    end

    local playbackUrl, trackTitle, rawUrl, streamErr = resolvePlaybackUrlAndTitle(safeUrl)
    if streamErr then
        notifySource(src, streamErr .. " Dahili oynatıcı denenecek.")
    end

    stations[getStationKey(netId)] = {
        url = playbackUrl,
        rawUrl = rawUrl,
        title = trackTitle,
        volume = clamp(tonumber(volume) or DEFAULT_VOLUME, MIN_VOLUME, MAX_VOLUME),
        distance = clamp(tonumber(distance) or DEFAULT_DISTANCE, MIN_DISTANCE, MAX_DISTANCE),
        paused = false
    }

    broadcastStation(netId)
end)

RegisterNetEvent("car_radio:server:pause", function(netId)
    local src = source
    netId = tonumber(netId)

    if not netId or not canControlVehicle(src, netId) then
        return
    end

    local key = getStationKey(netId)
    local station = stations[key]
    if not station then
        return
    end

    station.paused = true
    broadcastStation(netId)
end)

RegisterNetEvent("car_radio:server:resume", function(netId)
    local src = source
    netId = tonumber(netId)

    if not netId or not canControlVehicle(src, netId) then
        return
    end

    local key = getStationKey(netId)
    local station = stations[key]
    if not station then
        return
    end

    station.paused = false
    broadcastStation(netId)
end)

RegisterNetEvent("car_radio:server:stop", function(netId)
    local src = source
    netId = tonumber(netId)

    if not netId or not canControlVehicle(src, netId) then
        return
    end

    if not stations[getStationKey(netId)] then
        return
    end

    removeStation(netId)
end)

RegisterNetEvent("car_radio:server:setVolume", function(netId, volume, distance)
    local src = source
    netId = tonumber(netId)

    if not netId or not canControlVehicle(src, netId) then
        return
    end

    local key = getStationKey(netId)
    local station = stations[key]
    if not station then
        return
    end

    station.volume = clamp(tonumber(volume) or DEFAULT_VOLUME, MIN_VOLUME, MAX_VOLUME)

    if distance ~= nil then
        station.distance = clamp(tonumber(distance) or station.distance or DEFAULT_DISTANCE, MIN_DISTANCE, MAX_DISTANCE)
    end

    broadcastStation(netId)
end)

RegisterNetEvent("car_radio:server:setDistance", function(netId, distance)
    local src = source
    netId = tonumber(netId)

    if not netId or not canControlVehicle(src, netId) then
        return
    end

    local key = getStationKey(netId)
    local station = stations[key]
    if not station then
        return
    end

    station.distance = clamp(tonumber(distance) or DEFAULT_DISTANCE, MIN_DISTANCE, MAX_DISTANCE)
    broadcastStation(netId)
end)

CreateThread(function()
    while true do
        Wait(8000)

        for key in pairs(stations) do
            local netId = tonumber(key)
            if not netId then
                stations[key] = nil
            else
                local vehicle = NetworkGetEntityFromNetworkId(netId)
                if vehicle == 0 or not DoesEntityExist(vehicle) then
                    removeStation(netId)
                end
            end
        end
    end
end)

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName ~= GetCurrentResourceName() then
        return
    end

    for key in pairs(stations) do
        local netId = tonumber(key)
        if netId then
            TriggerClientEvent("car_radio:client:removeStation", -1, netId)
        end
    end

    stations = {}
end)