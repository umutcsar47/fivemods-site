﻿const app = document.getElementById("app")
const radioPanel = document.getElementById("radioPanel")
const dragHandle = document.getElementById("dragHandle")
const closeBtn = document.getElementById("closeBtn")

const urlInput = document.getElementById("urlInput")
const titleRow = document.getElementById("titleRow")
const titleText = document.getElementById("titleText")
const editLinkBtn = document.getElementById("editLinkBtn")

const playToggleBtn = document.getElementById("playToggleBtn")
const stopBtn = document.getElementById("stopBtn")

const volumeInput = document.getElementById("volumeInput")
const distanceInput = document.getElementById("distanceInput")
const volumeValue = document.getElementById("volumeValue")
const distanceValue = document.getElementById("distanceValue")
const statusBox = document.getElementById("statusBox")

const controls = document.querySelectorAll("button, input")

const VOLUME_SEND_DEBOUNCE_MS = 90
let volumeSendTimer = null
let resolveTimer = null

let transportState = "idle"
let activeUrl = ""
let activeTitle = ""
let pendingUrl = ""
let pendingTitle = ""
let panelXPercent = 60
let panelYPercent = 45
let dragState = null

function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value))
}

function setPanelPositionPx(leftPx, topPx) {
    const rect = radioPanel.getBoundingClientRect()
    const maxLeft = Math.max(0, window.innerWidth - rect.width)
    const maxTop = Math.max(0, window.innerHeight - rect.height)

    const finalLeft = clamp(leftPx, 0, maxLeft)
    const finalTop = clamp(topPx, 0, maxTop)

    radioPanel.style.left = `${finalLeft}px`
    radioPanel.style.top = `${finalTop}px`

    panelXPercent = clamp((finalLeft / Math.max(window.innerWidth, 1)) * 100, 1, 99)
    panelYPercent = clamp((finalTop / Math.max(window.innerHeight, 1)) * 100, 1, 99)
}

function setPanelPositionPercent(xPercent, yPercent) {
    panelXPercent = clamp(Number(xPercent) || 60, 1, 99)
    panelYPercent = clamp(Number(yPercent) || 45, 1, 99)
    radioPanel.style.left = `${panelXPercent}vw`
    radioPanel.style.top = `${panelYPercent}vh`
}

function post(action, payload = {}) {
    return fetch(`https://${GetParentResourceName()}/${action}`, {
        method: "POST",
        headers: { "Content-Type": "application/json; charset=UTF-8" },
        body: JSON.stringify(payload)
    }).then((res) => res.json().catch(() => ({})))
}

function setOpen(state) {
    app.classList.toggle("visible", state)
}

function setStatus(message, type = "idle") {
    statusBox.textContent = message
    statusBox.className = `status ${type === "idle" ? "" : type}`.trim()
}

function setTransportState(state) {
    transportState = state

    if (transportState === "playing") {
        playToggleBtn.textContent = "Dur"
        return
    }

    if (transportState === "paused") {
        playToggleBtn.textContent = "Devam"
        return
    }

    playToggleBtn.textContent = "Baslat"
}

function updateSliderTexts() {
    volumeValue.textContent = `${Math.round(Number(volumeInput.value))}%`
    distanceValue.textContent = `${Math.round(Number(distanceInput.value))}m`
}

function showTitlePreview(title) {
    if (!title) {
        return
    }

    titleText.textContent = title
    titleRow.classList.remove("hidden")
    urlInput.classList.add("hidden")
}

function showLinkInput(value) {
    titleRow.classList.add("hidden")
    urlInput.classList.remove("hidden")
    urlInput.value = value || ""
}

function clearPending() {
    pendingUrl = ""
    pendingTitle = ""
}

function handleResponse(promise, successMessage) {
    return promise
        .then((response) => {
            if (response && response.ok) {
                setStatus(successMessage, "ok")
                return response
            }

            setStatus((response && response.error) || "Islem basarisiz.", "error")
            return null
        })
        .catch(() => {
            setStatus("NUI bağlantı hatası.", "error")
            return null
        })
}

function resolveTitleFromInput(url) {
    const safeUrl = (url || "").trim()
    if (!safeUrl || transportState !== "idle") {
        return
    }

    post("resolveTitle", { url: safeUrl }).then((response) => {
        if (!response || response.ok !== true) {
            pendingUrl = safeUrl
            pendingTitle = safeUrl
            showTitlePreview(pendingTitle)
            setStatus((response && response.error) || "Sarki adi alinamadi.", "warn")
            return
        }

        pendingUrl = (response.url || safeUrl).trim()
        pendingTitle = (response.title || safeUrl).trim()
        showTitlePreview(pendingTitle)
        setStatus("Sarki adi bulundu.", "ok")
    })
}

function scheduleTitleResolve() {
    if (resolveTimer) {
        clearTimeout(resolveTimer)
    }

    resolveTimer = setTimeout(() => {
        resolveTimer = null
        resolveTitleFromInput(urlInput.value)
    }, 450)
}

function getCandidateUrl() {
    const value = urlInput.value.trim()
    if (value) {
        pendingUrl = value
        return value
    }

    return pendingUrl || activeUrl
}

function getCandidateTitle(url) {
    return pendingTitle || activeTitle || url
}

closeBtn.addEventListener("click", async () => {
    await post("close")
    setOpen(false)
})

editLinkBtn.addEventListener("click", () => {
    if (transportState !== "idle") {
        setStatus("Link değiğtirmek için sarkıyı bitir.", "warn")
        return
    }

    showLinkInput(pendingUrl || activeUrl || "")
    setStatus("Yeni link girebilirsin.", "idle")
    urlInput.focus()
})

playToggleBtn.addEventListener("click", async () => {
    const candidateUrl = getCandidateUrl()
    const selectedDistance = clamp(Number(distanceInput.value), 8, 80)

    if (transportState === "idle") {
        if (!candidateUrl) {
            setStatus("YouTube veya stream linki girmelisin.", "warn")
            return
        }

        const response = await handleResponse(
            post("play", {
                url: candidateUrl,
                volume: clamp(Number(volumeInput.value) / 100, 0.05, 1.0),
                distance: selectedDistance
            }),
            "Radyo acildi."
        )

        if (response) {
            activeUrl = candidateUrl
            activeTitle = getCandidateTitle(candidateUrl)
            showTitlePreview(activeTitle)
            setTransportState("playing")
        }
        return
    }

    if (transportState === "playing") {
        const response = await handleResponse(post("pause"), "Radyo duraklatıldı.")
        if (response) {
            setTransportState("paused")
        }
        return
    }

    const response = await handleResponse(post("resume"), "Radyo devam ediyor.")
    if (response) {
        setTransportState("playing")
    }
})

stopBtn.addEventListener("click", async () => {
    const response = await handleResponse(post("stop"), "Radyo kapatildi.")
    if (response) {
        activeUrl = ""
        activeTitle = ""
        clearPending()
        setTransportState("idle")
        showLinkInput("")
        urlInput.focus()
    }
})

volumeInput.addEventListener("input", () => {
    updateSliderTexts()

    if (volumeSendTimer) {
        clearTimeout(volumeSendTimer)
    }

    volumeSendTimer = setTimeout(() => {
        volumeSendTimer = null
        if (transportState === "idle") {
            return
        }
        post("setVolume", { volume: clamp(Number(volumeInput.value) / 100, 0.05, 1.0) })
    }, VOLUME_SEND_DEBOUNCE_MS)
})

volumeInput.addEventListener("change", () => {
    if (volumeSendTimer) {
        clearTimeout(volumeSendTimer)
        volumeSendTimer = null
    }

    if (transportState !== "idle") {
        handleResponse(post("setVolume", { volume: clamp(Number(volumeInput.value) / 100, 0.05, 1.0) }), "Ses guncellendi.")
    }
})

distanceInput.addEventListener("input", () => {
    updateSliderTexts()
})

distanceInput.addEventListener("change", () => {
    const distance = clamp(Number(distanceInput.value), 8, 80)
    handleResponse(post("setDistance", { distance }), "Ses mesafesi guncellendi.")
})

urlInput.addEventListener("input", () => {
    if (transportState !== "idle") {
        return
    }

    clearPending()
    const current = urlInput.value.trim()
    if (!current) {
        setStatus("Link bekleniyor...", "idle")
        return
    }

    scheduleTitleResolve()
})

urlInput.addEventListener("paste", () => {
    if (transportState !== "idle") {
        return
    }

    setTimeout(() => {
        const value = urlInput.value.trim()
        if (value) {
            resolveTitleFromInput(value)
        }
    }, 20)
})

urlInput.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" || transportState !== "idle") {
        return
    }

    const value = urlInput.value.trim()
    if (value) {
        resolveTitleFromInput(value)
    }
})

window.addEventListener("message", (event) => {
    const data = event.data || {}

    if (data.action === "open") {
        setOpen(true)
        return
    }

    if (data.action === "close") {
        setOpen(false)
        return
    }

    if (data.action === "error") {
        setStatus(data.message || "Radyo hatası.", "error")
        return
    }

    if (data.action === "setState") {
        const canControl = data.canControl !== false

        controls.forEach((control) => {
            control.disabled = !canControl
        })

        if (!canControl) {
            setTransportState("idle")
            setStatus(data.error || "Radyoyu kullanmak için herhangi bir araca bin.", "warn")
            return
        }

        const station = data.station || {}
        if (station.playing) {
            activeUrl = station.rawUrl || station.url || ""
            activeTitle = station.title || activeUrl
            pendingTitle = activeTitle
            pendingUrl = activeUrl
            showTitlePreview(activeTitle)
            setTransportState(station.paused ? "paused" : "playing")
            if (typeof station.volume === "number") {
                volumeInput.value = String(Math.round(clamp(station.volume, 0.05, 1.0) * 100))
            }
            if (typeof station.distance === "number") {
                distanceInput.value = String(Math.round(clamp(station.distance, 8, 80)))
            }
        } else {
            activeUrl = ""
            activeTitle = ""
            clearPending()
            showLinkInput("")
            setTransportState("idle")
        }

        if (data.ui && data.ui.position) {
            setPanelPositionPercent(data.ui.position.x || 60, data.ui.position.y || 45)
        }
        if (data.ui && typeof data.ui.scale === "number") {
            radioPanel.style.setProperty("--panel-scale", data.ui.scale.toFixed(2))
        }

        updateSliderTexts()
    }
})

if (dragHandle) {
    dragHandle.addEventListener("mousedown", (event) => {
        if (!app.classList.contains("visible")) {
            return
        }

        if (event.button !== 0) {
            return
        }

        if (event.target.closest("button") || event.target.closest("input")) {
            return
        }

        const rect = radioPanel.getBoundingClientRect()
        dragState = {
            startX: event.clientX,
            startY: event.clientY,
            startLeft: rect.left,
            startTop: rect.top
        }

        document.body.style.userSelect = "none"
    })
}

window.addEventListener("mousemove", (event) => {
    if (!dragState) {
        return
    }

    const deltaX = event.clientX - dragState.startX
    const deltaY = event.clientY - dragState.startY
    const nextLeft = dragState.startLeft + deltaX
    const nextTop = dragState.startTop + deltaY

    setPanelPositionPx(nextLeft, nextTop)
})

window.addEventListener("mouseup", async () => {
    if (!dragState) {
        return
    }

    dragState = null
    document.body.style.userSelect = ""

    await post("setUiPosition", { x: panelXPercent, y: panelYPercent })
})

window.addEventListener("resize", () => {
    setPanelPositionPercent(panelXPercent, panelYPercent)
})

document.addEventListener("keyup", async (event) => {
    if (event.key !== "Escape" || !app.classList.contains("visible")) {
        return
    }

    await post("close")
    setOpen(false)
})

showLinkInput("")
setTransportState("idle")
updateSliderTexts()
setStatus("Hazır.", "idle")
