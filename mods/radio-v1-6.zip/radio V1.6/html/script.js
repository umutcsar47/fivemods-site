
const app = document.getElementById("app")
const radioPanel = document.getElementById("radioPanel")
const dragHandle = document.getElementById("dragHandle")
const statusBox = document.getElementById("statusBox")

const settingsBtn = document.getElementById("settingsBtn")
const closeBtn = document.getElementById("closeBtn")

const urlInput = document.getElementById("urlInput")
const urlInputWrap = document.getElementById("urlInputWrap")
const titlePreviewWrap = document.getElementById("titlePreviewWrap")
const titlePreviewText = document.getElementById("titlePreviewText")
const editLinkBtn = document.getElementById("editLinkBtn")
const trackThumb = document.getElementById("trackThumb")

const saveTrackBtn = document.getElementById("saveTrackBtn")
const savedToggleBtn = document.getElementById("savedToggleBtn")
const savedBlock = document.getElementById("savedBlock")
const savedTracksContainer = document.getElementById("savedTracks")

const volumeInput = document.getElementById("volumeInput")
const distanceInput = document.getElementById("distanceInput")
const volumeValue = document.getElementById("volumeValue")
const distanceValue = document.getElementById("distanceValue")
const eqPanel = document.getElementById("eqPanel")
const eqBars = Array.from(document.querySelectorAll(".eq-bar"))
const eqLabel = document.querySelector(".eq-label")
const transportToggleBtn = document.getElementById("transportToggleBtn")
const transportIcon = document.getElementById("transportIcon")
const transportText = document.getElementById("transportText")
const stopBtn = document.getElementById("stopBtn")

const sizeOverlay = document.getElementById("sizeOverlay")
const sizeInput = document.getElementById("sizeInput")
const sizeValue = document.getElementById("sizeValue")
const widthInput = document.getElementById("widthInput")
const heightInput = document.getElementById("heightInput")
const widthValue = document.getElementById("widthValue")
const heightValue = document.getElementById("heightValue")
const closeSizeModalBtn = document.getElementById("closeSizeModalBtn")

const controls = document.querySelectorAll(".control")

const MAX_SAVED_TRACKS = 50
const SAVED_TRACKS_KEY = "car_radio_saved_tracks_v1"
const VOLUME_SEND_DEBOUNCE_MS = 90
const MIN_PANEL_SCALE = 0.70
const MAX_PANEL_SCALE = 1.40
const MIN_PANEL_WIDTH_SCALE = 0.85
const MAX_PANEL_WIDTH_SCALE = 1.30
const MIN_PANEL_HEIGHT_SCALE = 0.70
const MAX_PANEL_HEIGHT_SCALE = 1.80
const MIN_UI_SCALE = 0.85
const MAX_UI_SCALE = 1.30
const UI_SCALE_STRENGTH = 0.6

const ICON_PLAY = '<svg viewBox="0 0 24 24" aria-hidden="true" class="icon-svg"><path d="M8 6v12l10-6z"></path></svg>'
const ICON_PAUSE = '<svg viewBox="0 0 24 24" aria-hidden="true" class="icon-svg"><path d="M7 6h4v12H7zM13 6h4v12h-4z"></path></svg>'

const EQ_STYLE_OPTIONS = ["classic", "led", "block", "needle", "spectrum", "dots", "holo", "pulse", "flow", "scan", "solid"]
const EQ_BPM_MIN = 60
const EQ_BPM_MAX = 180
const EQ_TAP_TIMEOUT = 8000
const EQ_SILENCE_THRESHOLD = 0.12
const THEME_KEY = "car_radio_theme_v1"
const THEME_DEFAULT = "blue"
let canControl = true
let sizeModalOpen = false
let positionEditMode = false
let uiStateApplied = false

let panelScale = 1.0
let panelWidthScale = 1.0
let panelHeightScale = 1.0
let panelXPercent = 62
let panelYPercent = 45

let dragState = null
let transportState = "idle"
let eqLevels = eqBars.map(() => 0.12)
let eqTimer = null
let eqLastFrame = 0
let eqPhase = 0
let eqBeat = 0
let eqBpm = 120
let eqBeatStart = 0
let eqTapTimes = []
let eqLastTapAt = 0
let eqEnabled = false

let activeStationUrl = ""
let activeStationTitle = ""
let pendingResolvedUrl = ""
let pendingResolvedTitle = ""
let resolveTitleTimer = null
let volumeSendTimer = null

let savedTracks = []
let savedListOpen = false
let editingSavedUrl = ""

function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value))
}

function post(action, payload = {}) {
    return fetch(`https://${GetParentResourceName()}/${action}`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json; charset=UTF-8"
        },
        body: JSON.stringify(payload)
    }).then((res) => res.json().catch(() => ({})))
}

function isYouTubeUrl(url) {
    return /(?:youtube\.com|youtu\.be)/i.test(String(url || ""))
}

function extractYouTubeId(url) {
    const value = String(url || "")
    const patterns = [
        /[?&]v=([\w-]+)/i,
        /youtu\.be\/([\w-]+)/i,
        /youtube\.com\/shorts\/([\w-]+)/i,
        /youtube\.com\/live\/([\w-]+)/i,
        /youtube\.com\/embed\/([\w-]+)/i,
        /youtube\.com\/v\/([\w-]+)/i
    ]

    for (const pattern of patterns) {
        const match = value.match(pattern)
        if (match && match[1]) {
            return match[1]
        }
    }

    return null
}

function getYouTubeThumbnail(url, quality = "max") {
    if (!isYouTubeUrl(url)) {
        return null
    }

    const id = extractYouTubeId(url)
    if (!id) {
        return null
    }

    const file = quality === "max" ? "maxresdefault.jpg" : "hqdefault.jpg"
    return `https://img.youtube.com/vi/${id}/${file}`
}

function setTrackThumbnail(url) {
    if (!trackThumb || !radioPanel) {
        return
    }

    const maxThumb = getYouTubeThumbnail(url, "max")
    const fallbackThumb = getYouTubeThumbnail(url, "hq")
    if (!maxThumb) {
        trackThumb.classList.add("hidden")
        trackThumb.removeAttribute("src")
        trackThumb.removeAttribute("alt")
        trackThumb.dataset.fallback = ""
        trackThumb.dataset.state = ""
        radioPanel.style.setProperty("--track-art", "none")
        return
    }

    trackThumb.dataset.fallback = fallbackThumb || ""
    trackThumb.dataset.state = "max"
    trackThumb.src = maxThumb
    trackThumb.alt = "Kapak"
    trackThumb.classList.remove("hidden")
    radioPanel.style.setProperty("--track-art", `url("${maxThumb}")`)
}

if (trackThumb) {
    trackThumb.addEventListener("error", () => {
        const fallback = trackThumb.dataset.fallback
        if (trackThumb.dataset.state === "max" && fallback) {
            trackThumb.dataset.state = "fallback"
            trackThumb.src = fallback
            radioPanel.style.setProperty("--track-art", `url("${fallback}")`)
            return
        }

        trackThumb.classList.add("hidden")
        trackThumb.removeAttribute("src")
        trackThumb.dataset.state = ""
        radioPanel.style.setProperty("--track-art", "none")
    })
}

function deriveTitleFromUrl(url) {
    if (!url) {
        return "Bilinmeyen Sarki"
    }

    try {
        const parsed = new URL(url)
        const host = parsed.hostname.replace(/^www\./i, "")
        const parts = parsed.pathname.split("/").filter(Boolean)
        const slug = parts.length > 0 ? parts[parts.length - 1] : ""

        if (slug) {
            const decoded = decodeURIComponent(slug)
                .replace(/[-_]+/g, " ")
                .replace(/\s+/g, " ")
                .trim()

            if (decoded.length >= 3) {
                return decoded
            }
        }

        return host || url
    } catch (_) {
        return String(url)
    }
}
function setOpen(state) {
    app.classList.toggle("visible", state)

    if (!state) {
        closeAdjustMode(true)
        uiStateApplied = false
    }
}

function setStatus(message, type = "idle") {
    statusBox.textContent = message
    statusBox.className = `status status-${type}`
}

function setTransportState(state) {
    transportState = state
    if (eqPanel) {
        eqPanel.classList.toggle("is-playing", transportState === "playing")
        eqPanel.classList.toggle("is-paused", transportState === "paused")
        eqPanel.classList.toggle("is-idle", transportState === "idle")
    }
    if (stopBtn) {
        stopBtn.classList.toggle("hidden", transportState === "idle")
    }

    if (transportState === "playing") {
        if (eqEnabled) {
            startEqMotion()
        }
        transportIcon.innerHTML = ICON_PAUSE
        transportText.textContent = "Dur"
        return
    }

    if (transportState === "paused") {
        stopEqMotion()
        transportIcon.innerHTML = ICON_PLAY
        transportText.textContent = "Devam"
        return
    }

    stopEqMotion()
    transportIcon.innerHTML = ICON_PLAY
    transportText.textContent = "Baslat"
    transportState = "idle"
    if (eqPanel) {
        eqPanel.classList.add("is-idle")
        eqPanel.classList.remove("is-playing", "is-paused")
    }
}

function applyEqStyle(styleId) {
    const resolved = EQ_STYLE_OPTIONS.includes(styleId) ? styleId : EQ_STYLE_OPTIONS[0]
    if (!eqPanel) {
        return
    }

    EQ_STYLE_OPTIONS.forEach((style) => {
        eqPanel.classList.toggle(`eq-style-${style}`, style === resolved)
    })

    const eqButtons = Array.from(document.querySelectorAll(".eq-style-btn[data-eq]"))
    eqButtons.forEach((button) => {
        button.classList.toggle("is-selected", button.dataset.eq === resolved)
    })

    localStorage.setItem("car_radio_eq_style_v2", resolved)
}

function setEqEnabled(enabled, persist = true) {
    eqEnabled = Boolean(enabled)
    if (!eqPanel) {
        return
    }

    eqPanel.classList.toggle("is-hidden", !eqEnabled)
    eqPanel.setAttribute("aria-hidden", String(!eqEnabled))

    const toggleBtn = document.getElementById("eqToggleBtn")
    if (toggleBtn) {
        toggleBtn.classList.toggle("is-on", eqEnabled)
        toggleBtn.textContent = eqEnabled ? "Ekolayzir: Acik" : "Ekolayzir: Kapali"
        toggleBtn.setAttribute("aria-pressed", String(eqEnabled))
    }

    if (!eqEnabled) {
        stopEqMotion()
        resetEqTempo()
    } else {
        resetEqTempo()
        if (transportState === "playing") {
            startEqMotion()
        }
    }

    if (persist) {
        localStorage.setItem("car_radio_eq_enabled_v2", eqEnabled ? "1" : "0")
    }
}

function applyTheme(theme, persist = true) {
    const resolved = theme === "green" ? "green" : "blue"
    if (document.body) {
        document.body.classList.toggle("theme-green", resolved === "green")
    }

    const themeButtons = Array.from(document.querySelectorAll(".theme-btn"))
    themeButtons.forEach((button) => {
        button.classList.toggle("is-selected", button.dataset.theme === resolved)
    })

    if (persist) {
        localStorage.setItem(THEME_KEY, resolved)
    }
}
function initAppearanceControls() {
    const eqToggleBtn = document.getElementById("eqToggleBtn")
    if (eqToggleBtn) {
        eqToggleBtn.addEventListener("click", () => {
            const isOn = eqToggleBtn.classList.contains("is-on")
            setEqEnabled(!isOn)
        })
    }

    const eqButtons = Array.from(document.querySelectorAll(".eq-style-btn[data-eq]"))
    eqButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const styleId = button.dataset.eq || "classic"
            applyEqStyle(styleId)
        })
    })

    const themeButtons = Array.from(document.querySelectorAll(".theme-btn"))
    themeButtons.forEach((button) => {
        button.addEventListener("click", () => {
            applyTheme(button.dataset.theme || THEME_DEFAULT)
        })
    })
    const storedEqStyle = localStorage.getItem("car_radio_eq_style_v2") || "classic"
    const storedEqEnabled = localStorage.getItem("car_radio_eq_enabled_v2")
    const storedTheme = localStorage.getItem(THEME_KEY) || THEME_DEFAULT
    applyEqStyle(storedEqStyle)
    setEqEnabled(storedEqEnabled === "1", false)
    applyTheme(storedTheme, false)

    if (eqLabel) {
        eqLabel.addEventListener("click", () => {
            if (!eqEnabled || transportState !== "playing") {
                return
            }
            registerEqTap()
        })
    }
}

function getEqIntensity() {
    const raw = Number(volumeInput.value) || 0
    return clamp(raw / 100, 0.05, 1)
}

function updateEqLabel() {
    if (!eqLabel) {
        return
    }

    if (eqTapTimes.length >= 2) {
        eqLabel.textContent = `EKOLAYZIR ? ${Math.round(eqBpm)} BPM`
    } else {
        eqLabel.textContent = "EKOLAYZIR"
    }
}

function resetEqTempo(now = performance.now()) {
    eqBpm = 120
    eqBeatStart = now
    eqTapTimes = []
    eqLastTapAt = 0
    updateEqLabel()
}

function ensureEqBeatStart(now = performance.now()) {
    if (!eqBeatStart) {
        eqBeatStart = now
    }
}

function registerEqTap() {
    const now = performance.now()

    if (eqLastTapAt && now - eqLastTapAt > EQ_TAP_TIMEOUT) {
        eqTapTimes = []
    }

    eqTapTimes.push(now)
    if (eqTapTimes.length > 6) {
        eqTapTimes.shift()
    }

    eqLastTapAt = now

    if (eqTapTimes.length >= 2) {
        const intervals = []
        for (let i = 1; i < eqTapTimes.length; i += 1) {
            intervals.push(eqTapTimes[i] - eqTapTimes[i - 1])
        }
        const avg = intervals.reduce((sum, value) => sum + value, 0) / intervals.length
        const bpm = clamp(60000 / Math.max(avg, 1), EQ_BPM_MIN, EQ_BPM_MAX)
        eqBpm = bpm
        eqBeatStart = now
    }

    updateEqLabel()
}
function updateEqFrame(timestamp) {
    if (eqBars.length === 0) {
        eqTimer = null
        eqLastFrame = 0
        return
    }

    const now = typeof timestamp === "number" ? timestamp : performance.now()
    const deltaMs = eqLastFrame ? Math.min(now - eqLastFrame, 80) : 16.7
    eqLastFrame = now
    const delta = clamp(deltaMs / 16.7, 0.55, 1.25)
    const isPlaying = transportState === "playing"
    const rawVolume = Number(volumeInput.value) || 0
    const intensity = isPlaying ? clamp(rawVolume / 100, 0.05, 1) : 0
    const isSilent = !isPlaying || rawVolume <= EQ_SILENCE_THRESHOLD * 100

    if (eqLastTapAt && now - eqLastTapAt > EQ_TAP_TIMEOUT) {
        eqTapTimes = []
        eqLastTapAt = 0
        eqBpm = 120
        updateEqLabel()
    }

    const hasTapTempo = eqTapTimes.length >= 2 && eqLastTapAt && now - eqLastTapAt <= EQ_TAP_TIMEOUT

    ensureEqBeatStart(now)
    const beatPhase = ((now - eqBeatStart) / 60000) * eqBpm
    const beatWave = Math.max(0, Math.sin(beatPhase * Math.PI * 2))
    const beatPulse = hasTapTempo ? Math.pow(beatWave, 2.4) : 0

    if (!isSilent) {
        eqPhase += (hasTapTempo ? 0.15 : 0.08) * delta
    }
    const sway = isSilent
        ? 0
        : hasTapTempo
            ? Math.sin(eqPhase * 0.22) * 0.035
            : Math.sin(eqPhase * 0.18) * 0.02

    const count = Math.max(eqBars.length - 1, 1)
    const base = isSilent ? 0.08 : (hasTapTempo ? 0.12 : 0.1)
    const motionScale = isSilent ? 0 : (hasTapTempo ? 0.26 + intensity * 0.3 : 0.18 + intensity * 0.2)
    const beatBoost = isSilent || !hasTapTempo ? 0 : (0.06 + 0.16 * intensity) * beatPulse

    const baseSmoothing = isSilent ? 0.18 : 0.12
    const smoothing = 1 - Math.pow(1 - baseSmoothing, delta)

    eqBars.forEach((bar, index) => {
        const norm = index / count
        const center = 1 - Math.abs(norm - 0.5) * 2
        const wave = Math.sin(eqPhase + index * 0.45) * 0.5 + 0.5
        const ripple = Math.sin(eqPhase * 0.8 + index * 0.9) * 0.5 + 0.5
        const shape = 0.35 + 0.65 * center
        const motion = 0.55 * wave + 0.45 * ripple

        const target = isPlaying
            ? base + intensity * motionScale * (0.45 + 0.55 * motion) * (0.7 + 0.3 * shape) + beatBoost + sway
            : base

        const next = eqLevels[index] + (target - eqLevels[index]) * smoothing
        const clamped = clamp(next, 0.06, 1)
        eqLevels[index] = clamped
        bar.style.setProperty("--eq-level", clamped.toFixed(3))
    })

    eqTimer = requestAnimationFrame(updateEqFrame)
}

function startEqMotion() {
    if (!eqEnabled || eqBars.length === 0 || eqTimer) {
        return
    }

    eqLastFrame = 0
    eqTimer = requestAnimationFrame(updateEqFrame)
}

function stopEqMotion() {
    if (eqTimer) {
        cancelAnimationFrame(eqTimer)
        eqTimer = null
    }

    eqLastFrame = 0

    if (eqBars.length === 0) {
        return
    }

    eqLevels = eqBars.map(() => 0.12)
    eqBars.forEach((bar) => {
        bar.style.setProperty("--eq-level", "0.12")
    })
}

function toInternalVolume() {
    return clamp(Number(volumeInput.value) / 100, 0.05, 1.0)
}

function sendVolumeUpdate(showStatus = false) {
    if (transportState === "idle") {
        return Promise.resolve(null)
    }

    const request = post("setVolume", {
        volume: toInternalVolume()
    })

    if (showStatus) {
        return handleResponse(request, "Ses guncellendi.")
    }

    return request.catch(() => null)
}

function updateSliderTexts() {
    volumeValue.textContent = `${Math.round(Number(volumeInput.value))}%`
    distanceValue.textContent = `${Math.round(Number(distanceInput.value))}m`
    sizeValue.textContent = `${Math.round(Number(sizeInput.value))}%`
    widthValue.textContent = `${Math.round(Number(widthInput.value))}%`
    heightValue.textContent = `${Math.round(Number(heightInput.value))}%`
}
function setPanelScale(scale) {
    panelScale = clamp(scale, MIN_PANEL_SCALE, MAX_PANEL_SCALE)
    radioPanel.style.setProperty("--panel-scale", panelScale.toFixed(2))
    sizeInput.value = String(Math.round(panelScale * 100))
    updateSliderTexts()
    refreshOverflowMarquees()
}

function setPanelDimensions(widthScale, heightScale) {
    const beforeRect = radioPanel.getBoundingClientRect()
    const centerX = beforeRect.left + beforeRect.width / 2
    const centerY = beforeRect.top + beforeRect.height / 2

    panelWidthScale = clamp(widthScale, MIN_PANEL_WIDTH_SCALE, MAX_PANEL_WIDTH_SCALE)
    panelHeightScale = clamp(heightScale, MIN_PANEL_HEIGHT_SCALE, MAX_PANEL_HEIGHT_SCALE)

    radioPanel.style.setProperty("--panel-width-scale", panelWidthScale.toFixed(2))
    radioPanel.style.setProperty("--panel-height-scale", panelHeightScale.toFixed(2))

    const blendedScale = (panelWidthScale + panelHeightScale) / 2
    const uiScale = clamp(1 + (blendedScale - 1) * UI_SCALE_STRENGTH, MIN_UI_SCALE, MAX_UI_SCALE)
    radioPanel.style.setProperty("--panel-ui-scale", uiScale.toFixed(2))

    widthInput.value = String(Math.round(panelWidthScale * 100))
    heightInput.value = String(Math.round(panelHeightScale * 100))
    updateSliderTexts()

    const afterRect = radioPanel.getBoundingClientRect()
    const nextLeft = centerX - afterRect.width / 2
    const nextTop = centerY - afterRect.height / 2
    setPanelPositionPx(nextLeft, nextTop)

    refreshOverflowMarquees()
}

function setPanelPositionPercent(x, y) {
    panelXPercent = clamp(x, 1, 99)
    panelYPercent = clamp(y, 1, 99)

    const width = window.innerWidth || 1
    const height = window.innerHeight || 1
    const rect = radioPanel.getBoundingClientRect()

    const nextLeft = (panelXPercent / 100) * width
    const nextTop = (panelYPercent / 100) * height

    const clampedLeft = clamp(nextLeft, 0, width - rect.width)
    const clampedTop = clamp(nextTop, 0, height - rect.height)

    radioPanel.style.left = `${clampedLeft}px`
    radioPanel.style.top = `${clampedTop}px`

    panelXPercent = clamp((clampedLeft / width) * 100, 1, 99)
    panelYPercent = clamp((clampedTop / height) * 100, 1, 99)
}

function setPanelPositionPx(x, y) {
    const width = window.innerWidth || 1
    const height = window.innerHeight || 1
    const rect = radioPanel.getBoundingClientRect()

    const nextLeft = clamp(x, 0, width - rect.width)
    const nextTop = clamp(y, 0, height - rect.height)

    radioPanel.style.left = `${nextLeft}px`
    radioPanel.style.top = `${nextTop}px`
    panelXPercent = clamp((nextLeft / width) * 100, 1, 99)
    panelYPercent = clamp((nextTop / height) * 100, 1, 99)
}
function resetPanelIfHidden() {
    if (!radioPanel) {
        return
    }

    const width = window.innerWidth || 1
    const height = window.innerHeight || 1
    const rect = radioPanel.getBoundingClientRect()
    const margin = 24

    const offscreen =
        rect.right < margin ||
        rect.left > width - margin ||
        rect.bottom < margin ||
        rect.top > height - margin

    if (offscreen) {
        setPanelPositionPercent(62, 45)
        post("setUiPosition", { x: panelXPercent, y: panelYPercent }).catch(() => null)
        return
    }

    setPanelPositionPx(rect.left, rect.top)
}

function updateControlState() {
    const disabled = !canControl || sizeModalOpen
    controls.forEach((control) => {
        if (sizeModalOpen && sizeOverlay.contains(control)) {
            control.disabled = false
            return
        }

        control.disabled = disabled
    })
}

function openAdjustMode() {
    sizeModalOpen = true
    sizeOverlay.classList.remove("hidden")
    radioPanel.classList.add("position-edit")
    updateControlState()
}

function closeAdjustMode(silent = false) {
    sizeModalOpen = false
    sizeOverlay.classList.add("hidden")
    radioPanel.classList.remove("position-edit")
    updateControlState()

    if (!silent) {
        setStatus("Ayarlar kaydedildi.", "ok")
    }
}

function handleResponse(request, successMessage, errorFallback = "Islem basarisiz.") {
    return request
        .then((response) => {
            if (response && response.ok) {
                if (successMessage) {
                    setStatus(successMessage, "ok")
                }
                return response
            }

            const message = response && response.error ? response.error : errorFallback
            if (message) {
                setStatus(message, "error")
            }
            return null
        })
        .catch(() => {
            setStatus(errorFallback, "error")
            return null
        })
}

function showUrlInput() {
    if (urlInputWrap) {
        urlInputWrap.classList.remove("hidden")
    }
    if (titlePreviewWrap) {
        titlePreviewWrap.classList.add("hidden")
    }
}

function showTitlePreview(title) {
    if (!titlePreviewWrap || !urlInputWrap) {
        return
    }
    titlePreviewWrap.classList.remove("hidden")
    urlInputWrap.classList.add("hidden")
    titlePreviewText.textContent = title || "Hazir"
    refreshOverflowMarquees()
}

function refreshOverflowMarquees() {
    const marqueeTargets = [
        titlePreviewText,
        ...Array.from(document.querySelectorAll(".saved-play-label"))
    ].filter(Boolean)

    marqueeTargets.forEach((node) => {
        const parent = node.parentElement
        if (!parent) {
            return
        }
        const shouldMarquee = node.scrollWidth > parent.clientWidth + 2
        node.classList.toggle("marquee", shouldMarquee)
        if (shouldMarquee) {
            const shift = Math.min(node.scrollWidth - parent.clientWidth + 12, 120)
            node.style.setProperty("--marquee-shift", `${shift}px`)
        } else {
            node.style.removeProperty("--marquee-shift")
        }
    })
}
function loadSavedTracks() {
    try {
        const raw = localStorage.getItem(SAVED_TRACKS_KEY)
        if (!raw) {
            return []
        }
        const parsed = JSON.parse(raw)
        if (!Array.isArray(parsed)) {
            return []
        }
        return parsed
            .map((item) => {
                if (!item || typeof item.url !== "string") {
                    return null
                }
                const title = typeof item.title === "string" && item.title.trim()
                    ? item.title.trim()
                    : deriveTitleFromUrl(item.url)
                return {
                    url: item.url,
                    title
                }
            })
            .filter(Boolean)
    } catch (_) {
        return []
    }
}

function saveSavedTracks() {
    try {
        localStorage.setItem(SAVED_TRACKS_KEY, JSON.stringify(savedTracks))
    } catch (_) {
        return
    }
}

function sortSavedTracks() {
    savedTracks.sort((a, b) => a.title.localeCompare(b.title, "tr", { sensitivity: "base" }))
}

function getSavedTitle(url) {
    const match = savedTracks.find((track) => track.url === url)
    return match ? match.title : ""
}

function renderSavedTracks() {
    if (!savedTracksContainer) {
        return
    }

    savedTracksContainer.innerHTML = ""

    if (savedTracks.length === 0) {
        const empty = document.createElement("p")
        empty.className = "saved-empty"
        empty.textContent = "Kayit yok."
        savedTracksContainer.appendChild(empty)
        return
    }

    savedTracks.forEach((track) => {
        const row = document.createElement("div")
        row.className = "saved-item"

                if (editingSavedUrl === track.url) {
            row.classList.add("is-editing")

            const input = document.createElement("input")
            input.className = "saved-edit-input"
            input.type = "text"
            input.value = track.title
            row.appendChild(input)

            const confirmBtn = document.createElement("button")
            confirmBtn.className = "saved-edit"
            confirmBtn.type = "button"
            confirmBtn.textContent = "OK"
            confirmBtn.addEventListener("click", () => {
                const nextTitle = input.value.trim() || deriveTitleFromUrl(track.url)
                track.title = nextTitle
                editingSavedUrl = ""
                sortSavedTracks()
                saveSavedTracks()
                renderSavedTracks()
                if (activeStationUrl === track.url) {
                    showTitlePreview(nextTitle)
                }
            })
            row.appendChild(confirmBtn)

            const deleteBtn = document.createElement("button")
            deleteBtn.className = "saved-remove"
            deleteBtn.type = "button"
            deleteBtn.textContent = "Sil"
            deleteBtn.addEventListener("click", () => {
                savedTracks = savedTracks.filter((item) => item.url !== track.url)
                saveSavedTracks()
                editingSavedUrl = ""
                renderSavedTracks()
            })
            row.appendChild(deleteBtn)

            const cancelBtn = document.createElement("button")
            cancelBtn.className = "saved-cancel"
            cancelBtn.type = "button"
            cancelBtn.textContent = "X"
            cancelBtn.addEventListener("click", () => {
                editingSavedUrl = ""
                renderSavedTracks()
            })
            row.appendChild(cancelBtn)

            input.focus()
            input.select()
            input.addEventListener("keydown", (event) => {
                if (event.key === "Enter") {
                    confirmBtn.click()
                } else if (event.key === "Escape") {
                    cancelBtn.click()
                }
            })
        } else {
            const playBtn = document.createElement("button")
            playBtn.className = "saved-play"
            playBtn.type = "button"
            playBtn.dataset.url = track.url
            playBtn.addEventListener("click", () => {
                if (!canControl || sizeModalOpen) {
                    return
                }
                urlInput.value = track.url
                pendingResolvedTitle = track.title
                pendingResolvedUrl = track.url
                showTitlePreview(track.title)
                handlePlay(track.url)
            })
            const label = document.createElement("span")
            label.className = "saved-play-label"
            label.textContent = track.title
            playBtn.appendChild(label)
            row.appendChild(playBtn)

            const editBtn = document.createElement("button")
            editBtn.className = "saved-edit"
            editBtn.type = "button"
            editBtn.title = "Duzenle"
            editBtn.innerHTML = "<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" class=\"icon-svg\"><path d=\"M4 17.5V20h2.5l10.8-10.8-2.5-2.5L4 17.5zm14.7-8.8c.4-.4.4-1 0-1.4l-2-2c-.4-.4-1-.4-1.4 0l-1.5 1.5 2.5 2.5 1.4-1.6z\"></path></svg>"
            editBtn.addEventListener("click", () => {
                editingSavedUrl = track.url
                renderSavedTracks()
            })
            row.appendChild(editBtn)
        }

        savedTracksContainer.appendChild(row)
    })

    refreshOverflowMarquees()
}

function toggleSavedList() {
    savedListOpen = !savedListOpen
    savedBlock.classList.toggle("collapsed", !savedListOpen)
    savedToggleBtn.classList.toggle("is-open", savedListOpen)
}

function handleSaveTrack() {
    const url = (activeStationUrl || urlInput.value || "").trim()
    if (!url) {
        setStatus("Link yok.", "warn")
        return
    }

    const existing = savedTracks.find((track) => track.url === url)
    const title = (activeStationTitle || pendingResolvedTitle || deriveTitleFromUrl(url)).trim()

    if (existing) {
        existing.title = existing.title || title
    } else {
        savedTracks.push({ url, title })
    }

    if (savedTracks.length > MAX_SAVED_TRACKS) {
        savedTracks = savedTracks.slice(0, MAX_SAVED_TRACKS)
    }

    sortSavedTracks()
    saveSavedTracks()
    renderSavedTracks()
    setStatus("Sarki kaydedildi.", "ok")
}
function handlePlay(candidateUrl) {
    if (!candidateUrl) {
        setStatus("Lutfen bir link girin.", "warn")
        return
    }

    const volume = toInternalVolume()
    const distance = clamp(Number(distanceInput.value) || 35, 8, 80)

    handleResponse(
        post("play", {
            url: candidateUrl,
            volume,
            distance
        }),
        "Radyo basladi."
    ).then((response) => {
        if (!response) {
            return
        }

        activeStationUrl = candidateUrl
        const savedTitle = getSavedTitle(candidateUrl)
        activeStationTitle = savedTitle || pendingResolvedTitle || deriveTitleFromUrl(candidateUrl)
        showTitlePreview(activeStationTitle)
        setTrackThumbnail(candidateUrl)
        setTransportState("playing")
    })
}

function requestTitleResolve(url) {
    if (!url) {
        return
    }

    const safeUrl = url.trim()
    if (!safeUrl) {
        return
    }

    post("resolveTitle", { url: safeUrl }).then((response) => {
        if (!response || response.ok !== true) {
            pendingResolvedUrl = safeUrl
            pendingResolvedTitle = deriveTitleFromUrl(safeUrl)
            showTitlePreview(pendingResolvedTitle)
            return
        }

        pendingResolvedUrl = safeUrl
        pendingResolvedTitle = response.title || deriveTitleFromUrl(safeUrl)
        showTitlePreview(pendingResolvedTitle)
        setTrackThumbnail(safeUrl)
    })
}

function applyStateFromServer(data) {
    canControl = data.canControl !== false
    updateControlState()

    if (data.error) {
        setStatus(data.error, "error")
    } else {
        setStatus("Hazir.", "idle")
    }

    if (data.ui && !uiStateApplied) {
        if (typeof data.ui.scale === "number") {
            setPanelScale(data.ui.scale)
        }
        if (typeof data.ui.width === "number" || typeof data.ui.height === "number") {
            const widthScale = typeof data.ui.width === "number" ? data.ui.width : panelWidthScale
            const heightScale = typeof data.ui.height === "number" ? data.ui.height : panelHeightScale
            setPanelDimensions(widthScale, heightScale)
        }
        if (data.ui.position) {
            setPanelPositionPercent(data.ui.position.x || panelXPercent, data.ui.position.y || panelYPercent)
        }
        uiStateApplied = true
            }

    const station = data.station || {}
    const url = station.rawUrl || station.url || ""
    const playing = station.playing === true
    const paused = station.paused === true

    if (typeof station.volume === "number") {
        volumeInput.value = String(Math.round(station.volume * 100))
    }
    if (typeof station.distance === "number") {
        distanceInput.value = String(Math.round(station.distance))
    }
    updateSliderTexts()

    if (url) {
        urlInput.value = url
        const savedTitle = getSavedTitle(url)
        const displayTitle = savedTitle || station.title || deriveTitleFromUrl(url)
        activeStationUrl = url
        activeStationTitle = displayTitle
        showTitlePreview(displayTitle)
        setTrackThumbnail(url)
    } else {
        activeStationUrl = ""
        activeStationTitle = ""
        showUrlInput()
        setTrackThumbnail("")
    }

    if (!playing) {
        setTransportState("idle")
    } else if (paused) {
        setTransportState("paused")
    } else {
        setTransportState("playing")
    }
}

function initSavedTracks() {
    savedTracks = loadSavedTracks()
    sortSavedTracks()
    renderSavedTracks()
}
if (savedToggleBtn) {
    savedToggleBtn.addEventListener("click", () => {
        if (!canControl || sizeModalOpen) {
            return
        }
        toggleSavedList()
    })
}

if (saveTrackBtn) {
    saveTrackBtn.addEventListener("click", () => {
        if (!canControl || sizeModalOpen) {
            return
        }
        handleSaveTrack()
    })
}

if (editLinkBtn) {
    editLinkBtn.addEventListener("click", () => {
        showUrlInput()
        urlInput.focus()
        urlInput.select()
    })
}

urlInput.addEventListener("input", () => {
    if (resolveTitleTimer) {
        clearTimeout(resolveTitleTimer)
    }
    const nextUrl = urlInput.value.trim()
    if (!nextUrl) {
        pendingResolvedTitle = ""
        pendingResolvedUrl = ""
        showUrlInput()
        return
    }

    resolveTitleTimer = setTimeout(() => {
        requestTitleResolve(nextUrl)
    }, 400)
})

urlInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        event.preventDefault()
        handlePlay(urlInput.value.trim())
    }
})

closeBtn.addEventListener("click", async () => {
    if (sizeModalOpen) {
        return
    }

    await post("close")
    setOpen(false)
})

settingsBtn.addEventListener("click", () => {
    if (!canControl) {
        return
    }

    if (sizeModalOpen) {
        closeAdjustMode()
    } else {
        openAdjustMode()
    }
})

if (dragHandle) {
    dragHandle.addEventListener("mousedown", (event) => {
        if (!sizeModalOpen) {
            return
        }
        const rect = radioPanel.getBoundingClientRect()
        dragState = {
            offsetX: event.clientX - rect.left,
            offsetY: event.clientY - rect.top
        }
        positionEditMode = true
    })

    dragHandle.addEventListener("dblclick", () => {
        if (!sizeModalOpen) {
            return
        }
        setPanelPositionPercent(62, 45)
        handleResponse(post("setUiPosition", { x: panelXPercent, y: panelYPercent }), "Konum sifirlandi.")
    })
    window.addEventListener("mousemove", (event) => {
        if (!positionEditMode || !dragState) {
            return
        }

        setPanelPositionPx(event.clientX - dragState.offsetX, event.clientY - dragState.offsetY)
    })

    window.addEventListener("mouseup", () => {
        if (!positionEditMode) {
            return
        }
        positionEditMode = false
        dragState = null
    })
}

sizeInput.addEventListener("input", () => {
    setPanelScale(Number(sizeInput.value) / 100)
})

widthInput.addEventListener("input", () => {
    setPanelDimensions(Number(widthInput.value) / 100, panelHeightScale)
})

heightInput.addEventListener("input", () => {
    setPanelDimensions(panelWidthScale, Number(heightInput.value) / 100)
})

closeSizeModalBtn.addEventListener("click", async () => {
    const scale = panelScale
    const widthScale = panelWidthScale
    const heightScale = panelHeightScale

    await Promise.all([
        handleResponse(post("setUiLayout", { scale, width: widthScale, height: heightScale }), "Boyutlar kaydedildi."),
        handleResponse(post("setUiPosition", { x: panelXPercent, y: panelYPercent }), "Konum kaydedildi.")
    ])

    closeAdjustMode()
})

transportToggleBtn.addEventListener("click", async () => {
    if (!canControl || sizeModalOpen) {
        return
    }

    if (transportState === "idle") {
        handlePlay(urlInput.value.trim())
        return
    }

    if (transportState === "playing") {
        const response = await handleResponse(post("pause"), "Radyo duraklatildi.")
        if (response) {
            setTransportState("paused")
        }
        return
    }

    const resumeResponse = await handleResponse(post("resume"), "Radyo devam ediyor.")
    if (resumeResponse) {
        setTransportState("playing")
    }
})

stopBtn.addEventListener("click", async () => {
    if (!canControl || sizeModalOpen) {
        return
    }

    const response = await handleResponse(post("stop"), "Radyo kapatildi.")
    if (response) {
        activeStationUrl = ""
        activeStationTitle = ""
        setTransportState("idle")
        setTrackThumbnail("")
    }
})

volumeInput.addEventListener("input", () => {
    updateSliderTexts()
    if (volumeSendTimer) {
        clearTimeout(volumeSendTimer)
    }
    volumeSendTimer = setTimeout(() => {
        sendVolumeUpdate()
    }, VOLUME_SEND_DEBOUNCE_MS)
})

volumeInput.addEventListener("change", () => {
    if (transportState === "idle") {
        return
    }
    handleResponse(post("setVolume", { volume: toInternalVolume() }), "Ses guncellendi.")
})

distanceInput.addEventListener("input", () => {
    updateSliderTexts()
})

distanceInput.addEventListener("change", () => {
    const distance = clamp(Number(distanceInput.value), 8, 80)
    handleResponse(post("setDistance", { distance }), "3D mesafe guncellendi.")
})

window.addEventListener("message", (event) => {
    const data = event.data || {}

    if (data.action === "open") {
        setOpen(true)
                return
    }

    if (data.action === "close") {
        setOpen(false)
        return
    }

    if (data.action === "setState") {
        applyStateFromServer(data)
        return
    }

    if (data.action === "error") {
        if (data.message) {
            setStatus(data.message, "error")
        }
    }
})

window.addEventListener("resize", () => {
    refreshOverflowMarquees()
})

initSavedTracks()
initAppearanceControls()
updateSliderTexts()












































