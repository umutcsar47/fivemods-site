﻿const app = document.getElementById("app")
const radioPanel = document.getElementById("radioPanel")
const settingsBtn = document.getElementById("settingsBtn")
const closeBtn = document.getElementById("closeBtn")
const dragHandle = document.getElementById("dragHandle")

const urlInput = document.getElementById("urlInput")
const titleRow = document.getElementById("titleRow")
const titleText = document.getElementById("titleText")
const editLinkBtn = document.getElementById("editLinkBtn")

const transportToggleBtn = document.getElementById("transportToggleBtn")
const transportIcon = document.getElementById("transportIcon")
const transportText = document.getElementById("transportText")
const stopBtn = document.getElementById("stopBtn")

const volumeInput = document.getElementById("volumeInput")
const distanceInput = document.getElementById("distanceInput")
const volumeValue = document.getElementById("volumeValue")
const distanceValue = document.getElementById("distanceValue")
const statusBox = document.getElementById("statusBox")

const sizeOverlay = document.getElementById("sizeOverlay")
const sizeInput = document.getElementById("sizeInput")
const widthInput = document.getElementById("widthInput")
const sizeValue = document.getElementById("sizeValue")
const widthValue = document.getElementById("widthValue")
const sizeDoneBtn = document.getElementById("sizeDoneBtn")

const controls = document.querySelectorAll(".control")

const ICON_PLAY = '<svg viewBox="0 0 24 24" aria-hidden="true" class="icon-svg"><path d="M8 6v12l10-6z"></path></svg>'
const ICON_PAUSE = '<svg viewBox="0 0 24 24" aria-hidden="true" class="icon-svg"><path d="M7 6h4v12H7zM13 6h4v12h-4z"></path></svg>'

const VOLUME_SEND_DEBOUNCE_MS = 90
let volumeSendTimer = null
let resolveTimer = null

let transportState = "idle"
let activeUrl = ""
let activeTitle = ""
let pendingUrl = ""
let pendingTitle = ""
let canControl = true
let sizeModeOpen = false
let panelScale = 1.0
let panelWidthScale = 1.0
let panelHeightScale = 1.0
let panelXPercent = 60.0
let panelYPercent = 45.0
const dragState = {
    active: false,
    offsetX: 0,
    offsetY: 0
}

function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value))
}

function post(action, payload = {}) {
    return fetch(`https://${GetParentResourceName()}/${action}`, {
        method: "POST",
        headers: { "Content-Type": "application/json; charset=UTF-8" },
        body: JSON.stringify(payload)
    }).then((res) => res.json().catch(() => ({})))
}

function setOpen(state) {
    app.classList.toggle("visible", state)
    if (!state) {
        closeAdjustMode(true)
    }
}

function setStatus(message, type = "idle") {
    statusBox.textContent = message
    statusBox.className = `status ${type === "idle" ? "" : type}`.trim()
}

function setTransportState(state) {
    transportState = state
    if (transportState === "playing") {
        transportIcon.innerHTML = ICON_PAUSE
        transportText.textContent = "Dur"
        return
    }
    if (transportState === "paused") {
        transportIcon.innerHTML = ICON_PLAY
        transportText.textContent = "Devam"
        return
    }
    transportIcon.innerHTML = ICON_PLAY
    transportText.textContent = "Baslat"
}

function updateSliderTexts() {
    volumeValue.textContent = `${Math.round(Number(volumeInput.value))}%`
    distanceValue.textContent = `${Math.round(Number(distanceInput.value))}m`
    sizeValue.textContent = `${Math.round(Number(sizeInput.value))}%`
    widthValue.textContent = `${Math.round(Number(widthInput.value))}%`
}

function showTitlePreview(title) {
    if (!title) {
        return
    }

    titleText.textContent = title
    titleRow.classList.remove("hidden")
    urlInput.classList.add("hidden")
}

function showLinkInput(value) {
    titleRow.classList.add("hidden")
    urlInput.classList.remove("hidden")
    urlInput.value = value || ""
}

function clearPending() {
    pendingUrl = ""
    pendingTitle = ""
}

function handleResponse(promise, successMessage) {
    return promise
        .then((response) => {
            if (response && response.ok) {
                setStatus(successMessage, "ok")
                return response
            }

            setStatus((response && response.error) || "Islem basarisiz.", "error")
            return null
        })
        .catch(() => {
            setStatus("NUI baglanti hatasi.", "error")
            return null
        })
}

function resolveTitleFromInput(url) {
    const safeUrl = (url || "").trim()
    if (!safeUrl || transportState !== "idle") {
        return
    }

    post("resolveTitle", { url: safeUrl }).then((response) => {
        if (!response || response.ok !== true) {
            pendingUrl = safeUrl
            pendingTitle = safeUrl
            showTitlePreview(pendingTitle)
            setStatus((response && response.error) || "Sarki adi alinamadi.", "warn")
            return
        }

        pendingUrl = (response.url || safeUrl).trim()
        pendingTitle = (response.title || safeUrl).trim()
        showTitlePreview(pendingTitle)
        setStatus("Sarki adi bulundu.", "ok")
    })
}

function scheduleTitleResolve() {
    if (resolveTimer) {
        clearTimeout(resolveTimer)
    }

    resolveTimer = setTimeout(() => {
        resolveTimer = null
        resolveTitleFromInput(urlInput.value)
    }, 450)
}

function getCandidateUrl() {
    const value = urlInput.value.trim()
    if (value) {
        pendingUrl = value
        return value
    }

    return pendingUrl || activeUrl
}

function getCandidateTitle(url) {
    return pendingTitle || activeTitle || url
}

function updateControlState() {
    const disabled = !canControl || sizeModeOpen
    controls.forEach((control) => {
        if (sizeModeOpen && sizeOverlay.contains(control)) {
            control.disabled = false
            return
        }

        control.disabled = disabled
    })
}

function setPanelScale(scale) {
    panelScale = clamp(scale, 0.70, 1.40)
    radioPanel.style.setProperty("--panel-scale", panelScale.toFixed(2))
    sizeInput.value = String(Math.round(panelScale * 100))
    updateSliderTexts()
    setPanelPositionPercent(panelXPercent, panelYPercent)
}

function setPanelDimensions(widthScale, heightScale) {
    panelWidthScale = clamp(widthScale, 0.85, 1.30)
    panelHeightScale = clamp(heightScale, 0.70, 1.60)
    radioPanel.style.setProperty("--panel-width-scale", panelWidthScale.toFixed(2))
    radioPanel.style.setProperty("--panel-height-scale", panelHeightScale.toFixed(2))
    widthInput.value = String(Math.round(panelWidthScale * 100))
    updateSliderTexts()
    setPanelPositionPercent(panelXPercent, panelYPercent)
}

function setPanelPositionPercent(xPercent, yPercent) {
    panelXPercent = clamp(Number(xPercent) || panelXPercent, 1, 99)
    panelYPercent = clamp(Number(yPercent) || panelYPercent, 1, 99)
    radioPanel.style.left = `${panelXPercent}vw`
    radioPanel.style.top = `${panelYPercent}vh`
}

function setPanelPositionPx(leftPx, topPx) {
    const rect = radioPanel.getBoundingClientRect()
    const maxLeft = Math.max(0, window.innerWidth - rect.width)
    const maxTop = Math.max(0, window.innerHeight - rect.height)

    const clampedLeft = clamp(leftPx, 0, maxLeft)
    const clampedTop = clamp(topPx, 0, maxTop)

    const xPercent = clamp((clampedLeft / Math.max(1, window.innerWidth)) * 100, 1, 99)
    const yPercent = clamp((clampedTop / Math.max(1, window.innerHeight)) * 100, 1, 99)

    setPanelPositionPercent(xPercent, yPercent)
}

function openAdjustMode() {
    sizeModeOpen = true
    sizeOverlay.classList.remove("hidden")
    radioPanel.classList.add("position-edit")
    updateControlState()
    setStatus("Ayar modu acik: boyut/genislik ayarla, ustten surukleyerek konumla.", "warn")
}

function closeAdjustMode(silent = false) {
    sizeModeOpen = false
    sizeOverlay.classList.add("hidden")
    radioPanel.classList.remove("position-edit")
    updateControlState()
    if (!silent) {
        setStatus("Ayar modu kapatildi.", "ok")
    }
}

closeBtn.addEventListener("click", async () => {
    if (sizeModeOpen) {
        return
    }
    await post("close")
    setOpen(false)
})

settingsBtn.addEventListener("click", () => {
    if (!canControl || sizeModeOpen) {
        return
    }
    openAdjustMode()
})

dragHandle.addEventListener("mousedown", (event) => {
    if (!sizeModeOpen) {
        return
    }

    event.preventDefault()
    const rect = radioPanel.getBoundingClientRect()
    dragState.active = true
    dragState.offsetX = event.clientX - rect.left
    dragState.offsetY = event.clientY - rect.top
})

document.addEventListener("mousemove", (event) => {
    if (!dragState.active) {
        return
    }

    const targetLeft = event.clientX - dragState.offsetX
    const targetTop = event.clientY - dragState.offsetY
    setPanelPositionPx(targetLeft, targetTop)
})

document.addEventListener("mouseup", async () => {
    if (!dragState.active) {
        return
    }

    dragState.active = false
    await handleResponse(
        post("setUiPosition", { x: panelXPercent, y: panelYPercent }),
        "Konum kaydedildi."
    )
})

window.addEventListener("resize", () => {
    setPanelPositionPercent(panelXPercent, panelYPercent)
})

sizeInput.addEventListener("input", () => {
    const scale = clamp(Number(sizeInput.value) / 100, 0.70, 1.40)
    setPanelScale(scale)
})

widthInput.addEventListener("input", () => {
    const widthScale = clamp(Number(widthInput.value) / 100, 0.85, 1.30)
    setPanelDimensions(widthScale, panelHeightScale)
})

sizeDoneBtn.addEventListener("click", async () => {
    const scale = clamp(Number(sizeInput.value) / 100, 0.70, 1.40)
    const widthScale = clamp(Number(widthInput.value) / 100, 0.85, 1.30)

    const response = await handleResponse(
        post("setUiLayout", { scale, width: widthScale }),
        "Boyutlar kaydedildi."
    )

    if (response) {
        if (typeof response.scale === "number") {
            setPanelScale(response.scale)
        }

        const resolvedWidth = typeof response.width === "number" ? response.width : widthScale
        const resolvedHeight = typeof response.height === "number" ? response.height : panelHeightScale
        setPanelDimensions(resolvedWidth, resolvedHeight)
    }

    closeAdjustMode()
})

editLinkBtn.addEventListener("click", () => {
    if (transportState !== "idle") {
        setStatus("Link degistirmek icin sarkiyi kapat.", "warn")
        return
    }

    showLinkInput(pendingUrl || activeUrl || "")
    setStatus("Yeni link girebilirsin.", "idle")
    urlInput.focus()
})

transportToggleBtn.addEventListener("click", async () => {
    const candidateUrl = getCandidateUrl()
    const selectedDistance = clamp(Number(distanceInput.value), 8, 80)

    if (transportState === "idle") {
        if (!candidateUrl) {
            setStatus("YouTube veya stream linki girmelisin.", "warn")
            return
        }

        const response = await handleResponse(
            post("play", {
                url: candidateUrl,
                volume: clamp(Number(volumeInput.value) / 100, 0.05, 1.0),
                distance: selectedDistance
            }),
            "Radyo acildi."
        )

        if (response) {
            activeUrl = candidateUrl
            activeTitle = getCandidateTitle(candidateUrl)
            showTitlePreview(activeTitle)
            setTransportState("playing")
        }
        return
    }

    if (transportState === "playing") {
        const response = await handleResponse(post("pause"), "Radyo duraklatildi.")
        if (response) {
            setTransportState("paused")
        }
        return
    }

    const response = await handleResponse(post("resume"), "Radyo devam ediyor.")
    if (response) {
        setTransportState("playing")
    }
})

stopBtn.addEventListener("click", async () => {
    const response = await handleResponse(post("stop"), "Radyo kapatildi.")
    if (response) {
        activeUrl = ""
        activeTitle = ""
        clearPending()
        setTransportState("idle")
        showLinkInput("")
        urlInput.focus()
    }
})

volumeInput.addEventListener("input", () => {
    updateSliderTexts()

    if (volumeSendTimer) {
        clearTimeout(volumeSendTimer)
    }

    volumeSendTimer = setTimeout(() => {
        volumeSendTimer = null
        if (transportState === "idle") {
            return
        }
        post("setVolume", { volume: clamp(Number(volumeInput.value) / 100, 0.05, 1.0) })
    }, VOLUME_SEND_DEBOUNCE_MS)
})

volumeInput.addEventListener("change", () => {
    if (volumeSendTimer) {
        clearTimeout(volumeSendTimer)
        volumeSendTimer = null
    }

    if (transportState !== "idle") {
        handleResponse(post("setVolume", { volume: clamp(Number(volumeInput.value) / 100, 0.05, 1.0) }), "Ses guncellendi.")
    }
})

distanceInput.addEventListener("input", () => {
    updateSliderTexts()
})

distanceInput.addEventListener("change", () => {
    const distance = clamp(Number(distanceInput.value), 8, 80)
    handleResponse(post("setDistance", { distance }), "3D mesafe guncellendi.")
})

urlInput.addEventListener("input", () => {
    if (transportState !== "idle") {
        return
    }

    clearPending()
    const current = urlInput.value.trim()
    if (!current) {
        setStatus("Link bekleniyor...", "idle")
        return
    }

    scheduleTitleResolve()
})

urlInput.addEventListener("paste", () => {
    if (transportState !== "idle") {
        return
    }

    setTimeout(() => {
        const value = urlInput.value.trim()
        if (value) {
            resolveTitleFromInput(value)
        }
    }, 20)
})

urlInput.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" || transportState !== "idle") {
        return
    }

    const value = urlInput.value.trim()
    if (value) {
        resolveTitleFromInput(value)
    }
})

window.addEventListener("message", (event) => {
    const data = event.data || {}

    if (data.action === "open") {
        setOpen(true)
        return
    }

    if (data.action === "close") {
        setOpen(false)
        return
    }

    if (data.action === "error") {
        setStatus(data.message || "Radyo hatasi.", "error")
        return
    }

    if (data.action === "setState") {
        canControl = data.canControl !== false
        updateControlState()

        if (!canControl) {
            setTransportState("idle")
            setStatus(data.error || "Radyoyu kullanmak icin araca bin.", "warn")
            return
        }

        const station = data.station || {}
        if (station.playing) {
            activeUrl = station.rawUrl || station.url || ""
            activeTitle = station.title || activeUrl
            pendingTitle = activeTitle
            pendingUrl = activeUrl
            showTitlePreview(activeTitle)
            setTransportState(station.paused ? "paused" : "playing")
            if (typeof station.volume === "number") {
                volumeInput.value = String(Math.round(clamp(station.volume, 0.05, 1.0) * 100))
            }
            if (typeof station.distance === "number") {
                distanceInput.value = String(Math.round(clamp(station.distance, 8, 80)))
            }
        } else {
            activeUrl = ""
            activeTitle = ""
            clearPending()
            showLinkInput("")
            setTransportState("idle")
        }

        if (data.ui && typeof data.ui.scale === "number") {
            setPanelScale(data.ui.scale)
        }
        if (data.ui && typeof data.ui.width === "number") {
            panelWidthScale = data.ui.width
        }
        if (data.ui && typeof data.ui.height === "number") {
            panelHeightScale = data.ui.height
        }
        setPanelDimensions(panelWidthScale, panelHeightScale)

        if (data.ui && data.ui.position) {
            setPanelPositionPercent(data.ui.position.x, data.ui.position.y)
        }

        updateSliderTexts()
    }
})

document.addEventListener("keyup", async (event) => {
    if (event.key !== "Escape" || !app.classList.contains("visible")) {
        return
    }

    if (sizeModeOpen) {
        return
    }

    await post("close")
    setOpen(false)
})

showLinkInput("")
setTransportState("idle")
updateSliderTexts()
setStatus("Hazir.", "idle")
updateControlState()
setPanelPositionPercent(panelXPercent, panelYPercent)
