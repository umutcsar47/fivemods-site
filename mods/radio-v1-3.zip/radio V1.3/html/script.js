const app = document.getElementById("app")
const radioPanel = document.getElementById("radioPanel")
const dragHandle = document.getElementById("dragHandle")
const statusBox = document.getElementById("statusBox")

const settingsBtn = document.getElementById("settingsBtn")
const closeBtn = document.getElementById("closeBtn")

const urlInput = document.getElementById("urlInput")
const urlInputWrap = document.getElementById("urlInputWrap")
const titlePreviewWrap = document.getElementById("titlePreviewWrap")
const titlePreviewText = document.getElementById("titlePreviewText")
const editLinkBtn = document.getElementById("editLinkBtn")
const trackThumb = document.getElementById("trackThumb")

const volumeInput = document.getElementById("volumeInput")
const distanceInput = document.getElementById("distanceInput")
const volumeValue = document.getElementById("volumeValue")
const distanceValue = document.getElementById("distanceValue")

const transportToggleBtn = document.getElementById("transportToggleBtn")
const transportIcon = document.getElementById("transportIcon")
const transportText = document.getElementById("transportText")
const stopBtn = document.getElementById("stopBtn")

const sizeOverlay = document.getElementById("sizeOverlay")
const sizeInput = document.getElementById("sizeInput")
const sizeValue = document.getElementById("sizeValue")
const widthInput = document.getElementById("widthInput")
const heightInput = document.getElementById("heightInput")
const widthValue = document.getElementById("widthValue")
const heightValue = document.getElementById("heightValue")
const closeSizeModalBtn = document.getElementById("closeSizeModalBtn")

const controls = document.querySelectorAll(".control")

const VOLUME_SEND_DEBOUNCE_MS = 90
const MIN_PANEL_SCALE = 0.70
const MAX_PANEL_SCALE = 1.40
const MIN_PANEL_WIDTH_SCALE = 0.85
const MAX_PANEL_WIDTH_SCALE = 1.30
const MIN_PANEL_HEIGHT_SCALE = 0.70
const MAX_PANEL_HEIGHT_SCALE = 1.80
const MIN_UI_SCALE = 0.85
const MAX_UI_SCALE = 1.30
const UI_SCALE_STRENGTH = 0.6

const ICON_PLAY = '<svg viewBox="0 0 24 24" aria-hidden="true" class="icon-svg"><path d="M8 6v12l10-6z"></path></svg>'
const ICON_PAUSE = '<svg viewBox="0 0 24 24" aria-hidden="true" class="icon-svg"><path d="M7 6h4v12H7zM13 6h4v12h-4z"></path></svg>'

let canControl = true
let sizeModalOpen = false
let positionEditMode = false
let uiStateApplied = false

let panelScale = 1.0
let panelWidthScale = 1.0
let panelHeightScale = 1.0
let panelXPercent = 62
let panelYPercent = 45

let dragState = null
let transportState = "idle"

let activeStationUrl = ""
let activeStationTitle = ""
let pendingResolvedUrl = ""
let pendingResolvedTitle = ""
let resolveTitleTimer = null
let volumeSendTimer = null

function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value))
}

function post(action, payload = {}) {
    return fetch(`https://${GetParentResourceName()}/${action}`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json; charset=UTF-8"
        },
        body: JSON.stringify(payload)
    }).then((res) => res.json().catch(() => ({})))
}

function isYouTubeUrl(url) {
    return /(?:youtube\.com|youtu\.be)/i.test(String(url || ""))
}

function extractYouTubeId(url) {
    const value = String(url || "")
    const patterns = [
        /[?&]v=([\w-]+)/i,
        /youtu\.be\/([\w-]+)/i,
        /youtube\.com\/shorts\/([\w-]+)/i,
        /youtube\.com\/live\/([\w-]+)/i,
        /youtube\.com\/embed\/([\w-]+)/i,
        /youtube\.com\/v\/([\w-]+)/i
    ]

    for (const pattern of patterns) {
        const match = value.match(pattern)
        if (match && match[1]) {
            return match[1]
        }
    }

    return null
}

function getYouTubeThumbnail(url, quality = "max") {
    if (!isYouTubeUrl(url)) {
        return null
    }

    const id = extractYouTubeId(url)
    if (!id) {
        return null
    }

    const file = quality === "max" ? "maxresdefault.jpg" : "hqdefault.jpg"
    return `https://img.youtube.com/vi/${id}/${file}`
}

function setTrackThumbnail(url) {
    if (!trackThumb || !radioPanel) {
        return
    }

    const maxThumb = getYouTubeThumbnail(url, "max")
    const fallbackThumb = getYouTubeThumbnail(url, "hq")
    if (!maxThumb) {
        trackThumb.classList.add("hidden")
        trackThumb.removeAttribute("src")
        trackThumb.removeAttribute("alt")
        trackThumb.dataset.fallback = ""
        trackThumb.dataset.state = ""
        radioPanel.style.setProperty("--track-art", "none")
        return
    }

    trackThumb.dataset.fallback = fallbackThumb || ""
    trackThumb.dataset.state = "max"
    trackThumb.src = maxThumb
    trackThumb.alt = "Kapak"
    trackThumb.classList.remove("hidden")
    radioPanel.style.setProperty("--track-art", `url("${maxThumb}")`)
}

if (trackThumb) {
    trackThumb.addEventListener("error", () => {
        const fallback = trackThumb.dataset.fallback
        if (trackThumb.dataset.state === "max" && fallback) {
            trackThumb.dataset.state = "fallback"
            trackThumb.src = fallback
            radioPanel.style.setProperty("--track-art", `url("${fallback}")`)
            return
        }

        trackThumb.classList.add("hidden")
        trackThumb.removeAttribute("src")
        trackThumb.dataset.state = ""
        radioPanel.style.setProperty("--track-art", "none")
    })
}

function deriveTitleFromUrl(url) {
    if (!url) {
        return "Bilinmeyen Sarki"
    }

    try {
        const parsed = new URL(url)
        const host = parsed.hostname.replace(/^www\./i, "")
        const parts = parsed.pathname.split("/").filter(Boolean)
        const slug = parts.length > 0 ? parts[parts.length - 1] : ""

        if (slug) {
            const decoded = decodeURIComponent(slug)
                .replace(/[-_]+/g, " ")
                .replace(/\s+/g, " ")
                .trim()

            if (decoded.length >= 3) {
                return decoded
            }
        }

        return host || url
    } catch (_) {
        return String(url)
    }
}

function setOpen(state) {
    app.classList.toggle("visible", state)

    if (!state) {
        closeAdjustMode(true)
        uiStateApplied = false
    }
}

function setStatus(message, type = "idle") {
    statusBox.textContent = message
    statusBox.className = `status status-${type}`
}

function setTransportState(state) {
    transportState = state
    if (stopBtn) {
        stopBtn.classList.toggle("hidden", transportState === "idle")
    }

    if (transportState === "playing") {
        transportIcon.innerHTML = ICON_PAUSE
        transportText.textContent = "Dur"
        return
    }

    if (transportState === "paused") {
        transportIcon.innerHTML = ICON_PLAY
        transportText.textContent = "Devam"
        return
    }

    transportIcon.innerHTML = ICON_PLAY
    transportText.textContent = "Baslat"
    transportState = "idle"
}

function toInternalVolume() {
    return clamp(Number(volumeInput.value) / 100, 0.05, 1.0)
}

function sendVolumeUpdate(showStatus = false) {
    if (transportState === "idle") {
        return Promise.resolve(null)
    }

    const request = post("setVolume", {
        volume: toInternalVolume()
    })

    if (showStatus) {
        return handleResponse(request, "Ses guncellendi.")
    }

    return request.catch(() => null)
}

function updateSliderTexts() {
    volumeValue.textContent = `${Math.round(Number(volumeInput.value))}%`
    distanceValue.textContent = `${Math.round(Number(distanceInput.value))}m`
    sizeValue.textContent = `${Math.round(Number(sizeInput.value))}%`
    widthValue.textContent = `${Math.round(Number(widthInput.value))}%`
    heightValue.textContent = `${Math.round(Number(heightInput.value))}%`
}

function setPanelScale(scale) {
    panelScale = clamp(scale, MIN_PANEL_SCALE, MAX_PANEL_SCALE)
    radioPanel.style.setProperty("--panel-scale", panelScale.toFixed(2))
    sizeInput.value = String(Math.round(panelScale * 100))
    updateSliderTexts()
    refreshOverflowMarquees()
}

function setPanelDimensions(widthScale, heightScale) {
    const beforeRect = radioPanel.getBoundingClientRect()
    const centerX = beforeRect.left + beforeRect.width / 2
    const centerY = beforeRect.top + beforeRect.height / 2

    panelWidthScale = clamp(widthScale, MIN_PANEL_WIDTH_SCALE, MAX_PANEL_WIDTH_SCALE)
    panelHeightScale = clamp(heightScale, MIN_PANEL_HEIGHT_SCALE, MAX_PANEL_HEIGHT_SCALE)

    radioPanel.style.setProperty("--panel-width-scale", panelWidthScale.toFixed(2))
    radioPanel.style.setProperty("--panel-height-scale", panelHeightScale.toFixed(2))

    const blendedScale = (panelWidthScale + panelHeightScale) / 2
    const uiScale = clamp(1 + (blendedScale - 1) * UI_SCALE_STRENGTH, MIN_UI_SCALE, MAX_UI_SCALE)
    radioPanel.style.setProperty("--panel-ui-scale", uiScale.toFixed(2))

    widthInput.value = String(Math.round(panelWidthScale * 100))
    heightInput.value = String(Math.round(panelHeightScale * 100))
    updateSliderTexts()

    const afterRect = radioPanel.getBoundingClientRect()
    const nextLeft = centerX - afterRect.width / 2
    const nextTop = centerY - afterRect.height / 2
    setPanelPositionPx(nextLeft, nextTop)

    refreshOverflowMarquees()
}

function setPanelPositionPercent(x, y) {
    panelXPercent = clamp(x, 1, 99)
    panelYPercent = clamp(y, 1, 99)
    radioPanel.style.left = `${panelXPercent}vw`
    radioPanel.style.top = `${panelYPercent}vh`
}

function setPanelPositionPx(x, y) {
    const width = window.innerWidth || 1
    const height = window.innerHeight || 1
    const rect = radioPanel.getBoundingClientRect()

    const nextLeft = clamp(x, 0, width - rect.width)
    const nextTop = clamp(y, 0, height - rect.height)

    radioPanel.style.left = `${nextLeft}px`
    radioPanel.style.top = `${nextTop}px`

    const centerX = nextLeft + rect.width / 2
    const centerY = nextTop + rect.height / 2

    panelXPercent = clamp((centerX / width) * 100, 1, 99)
    panelYPercent = clamp((centerY / height) * 100, 1, 99)
}

function updateControlState() {
    const disabled = !canControl || sizeModalOpen
    controls.forEach((control) => {
        if (sizeModalOpen && sizeOverlay.contains(control)) {
            control.disabled = false
            return
        }

        control.disabled = disabled
    })
}

function openAdjustMode() {
    sizeModalOpen = true
    sizeOverlay.classList.remove("hidden")
    radioPanel.classList.add("position-edit")
    updateControlState()
}

function closeAdjustMode(silent = false) {
    sizeModalOpen = false
    sizeOverlay.classList.add("hidden")
    radioPanel.classList.remove("position-edit")
    updateControlState()

    if (!silent) {
        setStatus("Ayarlar kaydedildi.", "ok")
    }
}

function handleResponse(request, successMessage, errorFallback = "Islem basarisiz.") {
    return request
        .then((response) => {
            if (response && response.ok) {
                if (successMessage) {
                    setStatus(successMessage, "ok")
                }
                return response
            }

            const message = response && response.error ? response.error : errorFallback
            if (message) {
                setStatus(message, "error")
            }
            return null
        })
        .catch(() => {
            setStatus(errorFallback, "error")
            return null
        })
}

function showUrlInput() {
    if (urlInputWrap) {
        urlInputWrap.classList.remove("hidden")
    }
    if (titlePreviewWrap) {
        titlePreviewWrap.classList.add("hidden")
    }
}

function showTitlePreview(title) {
    if (!titlePreviewWrap || !urlInputWrap) {
        return
    }
    titlePreviewWrap.classList.remove("hidden")
    urlInputWrap.classList.add("hidden")
    titlePreviewText.textContent = title || "Hazir"
    refreshOverflowMarquees()
}

function refreshOverflowMarquees() {
    const marqueeTargets = [titlePreviewText].filter(Boolean)

    marqueeTargets.forEach((node) => {
        const parent = node.parentElement
        if (!parent) {
            return
        }
        const shouldMarquee = node.scrollWidth > parent.clientWidth + 2
        node.classList.toggle("marquee", shouldMarquee)
        if (shouldMarquee) {
            const shift = Math.min(node.scrollWidth - parent.clientWidth + 12, 120)
            node.style.setProperty("--marquee-shift", `${shift}px`)
        } else {
            node.style.removeProperty("--marquee-shift")
        }
    })
}

function handlePlay(candidateUrl) {
    if (!candidateUrl) {
        setStatus("Lutfen bir link girin.", "warn")
        return
    }

    const volume = toInternalVolume()
    const distance = clamp(Number(distanceInput.value) || 35, 8, 80)

    handleResponse(
        post("play", {
            url: candidateUrl,
            volume,
            distance
        }),
        "Radyo basladi."
    ).then((response) => {
        if (!response) {
            return
        }

        activeStationUrl = candidateUrl
        activeStationTitle = pendingResolvedTitle || deriveTitleFromUrl(candidateUrl)
        showTitlePreview(activeStationTitle)
        setTrackThumbnail(candidateUrl)
        setTransportState("playing")
    })
}

function requestTitleResolve(url) {
    if (!url) {
        return
    }

    const safeUrl = url.trim()
    if (!safeUrl) {
        return
    }

    post("resolveTitle", { url: safeUrl }).then((response) => {
        if (!response || response.ok !== true) {
            pendingResolvedUrl = safeUrl
            pendingResolvedTitle = deriveTitleFromUrl(safeUrl)
            showTitlePreview(pendingResolvedTitle)
            return
        }

        pendingResolvedUrl = safeUrl
        pendingResolvedTitle = response.title || deriveTitleFromUrl(safeUrl)
        showTitlePreview(pendingResolvedTitle)
        setTrackThumbnail(safeUrl)
    })
}

function applyStateFromServer(data) {
    canControl = data.canControl !== false
    updateControlState()

    if (data.error) {
        setStatus(data.error, "error")
    } else {
        setStatus("Hazir.", "idle")
    }

    if (data.ui && !uiStateApplied) {
        const nextScale = typeof data.ui.scale === "number" ? data.ui.scale : panelScale
        const widthScale = typeof data.ui.width === "number" ? data.ui.width : panelWidthScale
        const heightScale = typeof data.ui.height === "number" ? data.ui.height : panelHeightScale

        setPanelScale(nextScale)
        setPanelDimensions(widthScale, heightScale)

        if (data.ui.position) {
            const nextX = typeof data.ui.position.x === "number" ? data.ui.position.x : panelXPercent
            const nextY = typeof data.ui.position.y === "number" ? data.ui.position.y : panelYPercent
            setPanelPositionPercent(nextX, nextY)
        }

        uiStateApplied = true
    }

    const station = data.station || {}
    const url = station.rawUrl || station.url || ""
    const playing = station.playing === true
    const paused = station.paused === true

    if (typeof station.volume === "number") {
        volumeInput.value = String(Math.round(station.volume * 100))
    }
    if (typeof station.distance === "number") {
        distanceInput.value = String(Math.round(station.distance))
    }
    updateSliderTexts()

    if (url) {
        urlInput.value = url
        const displayTitle = station.title || deriveTitleFromUrl(url)
        activeStationUrl = url
        activeStationTitle = displayTitle
        showTitlePreview(displayTitle)
        setTrackThumbnail(url)
    } else {
        activeStationUrl = ""
        activeStationTitle = ""
        showUrlInput()
        setTrackThumbnail("")
    }

    if (!playing) {
        setTransportState("idle")
    } else if (paused) {
        setTransportState("paused")
    } else {
        setTransportState("playing")
    }
}

if (editLinkBtn) {
    editLinkBtn.addEventListener("click", () => {
        showUrlInput()
        urlInput.focus()
        urlInput.select()
    })
}

urlInput.addEventListener("input", () => {
    if (resolveTitleTimer) {
        clearTimeout(resolveTitleTimer)
    }
    const nextUrl = urlInput.value.trim()
    if (!nextUrl) {
        pendingResolvedTitle = ""
        pendingResolvedUrl = ""
        showUrlInput()
        return
    }

    resolveTitleTimer = setTimeout(() => {
        requestTitleResolve(nextUrl)
    }, 400)
})

urlInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        event.preventDefault()
        handlePlay(urlInput.value.trim())
    }
})

closeBtn.addEventListener("click", async () => {
    if (sizeModalOpen) {
        return
    }

    await post("close")
    setOpen(false)
})

settingsBtn.addEventListener("click", () => {
    if (!canControl) {
        return
    }

    if (sizeModalOpen) {
        closeAdjustMode()
    } else {
        openAdjustMode()
    }
})

if (dragHandle) {
    dragHandle.addEventListener("mousedown", (event) => {
        if (!sizeModalOpen) {
            return
        }
        const rect = radioPanel.getBoundingClientRect()
        dragState = {
            offsetX: event.clientX - rect.left,
            offsetY: event.clientY - rect.top
        }
        positionEditMode = true
    })

    window.addEventListener("mousemove", (event) => {
        if (!positionEditMode || !dragState) {
            return
        }

        setPanelPositionPx(event.clientX - dragState.offsetX, event.clientY - dragState.offsetY)
    })

    window.addEventListener("mouseup", () => {
        if (!positionEditMode) {
            return
        }
        positionEditMode = false
        dragState = null
    })
}

sizeInput.addEventListener("input", () => {
    setPanelScale(Number(sizeInput.value) / 100)
})

widthInput.addEventListener("input", () => {
    setPanelDimensions(Number(widthInput.value) / 100, panelHeightScale)
})

heightInput.addEventListener("input", () => {
    setPanelDimensions(panelWidthScale, Number(heightInput.value) / 100)
})

closeSizeModalBtn.addEventListener("click", async () => {
    const scale = panelScale
    const widthScale = panelWidthScale
    const heightScale = panelHeightScale

    await Promise.all([
        handleResponse(post("setUiLayout", { scale, width: widthScale, height: heightScale }), "Boyutlar kaydedildi."),
        handleResponse(post("setUiPosition", { x: panelXPercent, y: panelYPercent }), "Konum kaydedildi.")
    ])

    closeAdjustMode()
})

transportToggleBtn.addEventListener("click", async () => {
    if (!canControl || sizeModalOpen) {
        return
    }

    if (transportState === "idle") {
        handlePlay(urlInput.value.trim())
        return
    }

    if (transportState === "playing") {
        const response = await handleResponse(post("pause"), "Radyo duraklatildi.")
        if (response) {
            setTransportState("paused")
        }
        return
    }

    const resumeResponse = await handleResponse(post("resume"), "Radyo devam ediyor.")
    if (resumeResponse) {
        setTransportState("playing")
    }
})

stopBtn.addEventListener("click", async () => {
    if (!canControl || sizeModalOpen) {
        return
    }

    const response = await handleResponse(post("stop"), "Radyo kapatildi.")
    if (response) {
        activeStationUrl = ""
        activeStationTitle = ""
        setTransportState("idle")
        setTrackThumbnail("")
    }
})

volumeInput.addEventListener("input", () => {
    updateSliderTexts()
    if (volumeSendTimer) {
        clearTimeout(volumeSendTimer)
    }
    volumeSendTimer = setTimeout(() => {
        sendVolumeUpdate()
    }, VOLUME_SEND_DEBOUNCE_MS)
})

volumeInput.addEventListener("change", () => {
    if (transportState === "idle") {
        return
    }
    handleResponse(post("setVolume", { volume: toInternalVolume() }), "Ses guncellendi.")
})

distanceInput.addEventListener("input", () => {
    updateSliderTexts()
})

distanceInput.addEventListener("change", () => {
    const distance = clamp(Number(distanceInput.value), 8, 80)
    handleResponse(post("setDistance", { distance }), "3D mesafe guncellendi.")
})

window.addEventListener("message", (event) => {
    const data = event.data || {}

    if (data.action === "open") {
        setOpen(true)
        return
    }

    if (data.action === "close") {
        setOpen(false)
        return
    }

    if (data.action === "setState") {
        applyStateFromServer(data)
        return
    }

    if (data.action === "error") {
        if (data.message) {
            setStatus(data.message, "error")
        }
    }
})

window.addEventListener("resize", () => {
    refreshOverflowMarquees()
})

updateSliderTexts()
